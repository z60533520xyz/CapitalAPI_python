import urllib.request
import urllib.parse
import json
import csv
import re
import time
import os
from urllib.error import URLError

def extract_fee(text):
    """
    從保費字串中提取整數部分，例如 '保費5278元' -> 5278，'保費0元' 或 'N/A' -> 0。
    """
    if text == 'N/A' or text == '保費0元':
        return 0
    match = re.search(r'(\d+)', str(text))
    return int(match.group(1)) if match else 0

def post_request(url, data, headers, retries=3, timeout=20):
    """
    發送 POST 請求並返回 JSON 回應，支持重試和超時。
    """
    data_encoded = urllib.parse.urlencode(data).encode('utf-8')
    for attempt in range(retries):
        try:
            req = urllib.request.Request(url, data=data_encoded, headers=headers, method='POST')
            with urllib.request.urlopen(req, timeout=timeout) as response:
                raw_response = response.read().decode('utf-8')
                parsed = json.loads(raw_response)
                return parsed
        except json.JSONDecodeError as e:
            print(f"JSON 解析錯誤 (嘗試 {attempt + 1}/{retries}): {e}")
            print(f"原始回應 (前 200 字元): {raw_response[:200] if 'raw_response' in locals() else 'N/A'}...")
            if attempt < retries - 1:
                time.sleep(1)  # 重試前等待 1 秒
            else:
                return None
        except URLError as e:
            print(f"URLError (嘗試 {attempt + 1}/{retries}): {e}")
            if attempt < retries - 1:
                time.sleep(1)  # 重試前等待 1 秒
            else:
                return None
        except Exception as e:
            print(f"請求失敗 (嘗試 {attempt + 1}/{retries}): {e}")
            if attempt < retries - 1:
                time.sleep(1)  # 重試前等待 1 秒
            else:
                return None
    return None

def load_existing_data(filename):
    """
    載入現有 CSV 檔案的資料，返回 { (pet_type, pet_text, pet_body_type): row } 字典。
    """
    existing = {}
    if os.path.exists(filename):
        with open(filename, 'r', newline='', encoding='utf-8') as csvfile:
            reader = csv.DictReader(csvfile)
            for row in reader:
                key = (row['PET_TYPE'], row['PET_TEXT'], row['PET_BODY_TYPE'])
                existing[key] = row
    return existing

def write_row_to_csv(filename, row, fieldnames):
    """
    逐筆寫入 CSV 檔案（追加模式）。
    """
    file_exists = os.path.exists(filename)
    with open(filename, 'a', newline='', encoding='utf-8') as csvfile:
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        if not file_exists:
            writer.writeheader()
        writer.writerow(row)

# 第一個 API URL
url1 = 'https://www.cathay-ins.com.tw/INSEBWeb/BOBE/phone/ECN2_1001/getType'

# CSV 檔案名
filename = 'outputs/pet_insurance_calculation.csv'
fieldnames = ['PET_TYPE', 'PET_TEXT', 'PET_BODY_TYPE', 'BASIC_60_TOTAL', 'BASIC_80_TOTAL', 'CANCER_60_TOTAL']

# 載入現有資料
existing_data = load_existing_data(filename)
print(f"現有檔案中有 {len(existing_data)} 筆資料。")

# 收集新結果的列表（僅用於預覽）
new_results = []

# 對 PET_TYPE 0 (狗) 和 1 (貓) 分別執行
for pet_type in [0, 1]:
    data1 = {'PET_TYPE': str(pet_type)}
    headers1 = {
        'Content-Length': '10',  # 固定為 10，如您所述
        'X-Requested-With': 'XMLHttpRequest',
        'Content-Type': 'application/x-www-form-urlencoded',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }
    
    print(f"正在取得 PET_TYPE={pet_type} 的品種列表...")
    resp1 = post_request(url1, data1, headers1)
    
    if resp1 is None or not isinstance(resp1, dict) or resp1.get('ErrMsg', {}).get('returnCode') != 0:
        print(f"警告: PET_TYPE={pet_type} 的請求失敗、非 JSON 或有錯誤，跳過。")
        continue
    
    pet_type_name = '狗' if pet_type == 0 else '貓'
    pet_list = resp1.get('PET_TYPE_LIST', [])
    print(f"找到 {len(pet_list)} 個 {pet_type_name} 品種。")
    
    # 對每個品種處理
    for item in pet_list:
        pet_text = item.get('CODESUB_NAME', '')
        pet_body_type = item.get('CODESUB_EXPLAIN', '')
        validate = item.get('VALIDATE', 'Y')  # 預設為 'Y' 如果無此字段
        
        key = (pet_type_name, pet_text, pet_body_type)
        if key in existing_data:
            print(f"跳過已存在資料: {pet_type_name} - {pet_text} ({pet_body_type})")
            # 添加到新結果用於預覽
            row = existing_data[key]
            new_results.append(row)
            continue
        
        # 初始化結果為 0
        basic_60 = 0
        basic_80 = 0
        cancer_60 = 0
        
        if validate == 'N':
            print(f"跳過試算 {pet_type_name} - {pet_text} (VALIDATE=N)，保費設為0。")
        else:
            # 只有 VALIDATE != 'N' 才呼叫第二個 API
            data2 = {
                'PET_BODY_TYPE': pet_body_type,
                'PET_KG': '',  # 固定空字串
                'PET_BIRTH': '2024-10-08',
                'INS_DATE': '2025-10-09',
                'trxUniKey': 'ecced5815011483ebee08c625e4c5a72',
                'PET_TEXT': pet_text,
                'PET_TYPE': str(pet_type)
            }
            
            # 動態計算 Content-Length
            headers2 = {
                'X-Requested-With': 'XMLHttpRequest',
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            }
            data_encoded2 = urllib.parse.urlencode(data2).encode('utf-8')
            headers2['Content-Length'] = str(len(data_encoded2))
            
            # 第二個 API URL
            url2 = 'https://www.cathay-ins.com.tw/INSEBWeb/BOBE/phone/ECN2_1001/calculate'
            print(f"正在試算 {pet_type_name} - {pet_text} ({pet_body_type})...")
            
            resp2 = post_request(url2, data2, headers2)
            
            if resp2 is None or not isinstance(resp2, dict) or resp2.get('ErrMsg', {}).get('returnCode') != 0:
                print(f"警告: {pet_text} 的試算失敗、非 JSON 或有錯誤，保費設為0。")
            else:
                content = resp2.get('CONTENT', {})
                basic_60_str = content.get('BASIC_60_TOTAL', '保費0元')
                basic_80_str = content.get('BASIC_80_TOTAL', '保費0元')
                cancer_60_str = content.get('CANCER_60_TOTAL', '保費0元')
                basic_60 = extract_fee(basic_60_str)
                basic_80 = extract_fee(basic_80_str)
                cancer_60 = extract_fee(cancer_60_str)
                print(f"試算完成: {basic_60}, {basic_80}, {cancer_60}")
        
        # 收集結果（無論是否試算，都添加）
        row = {
            'PET_TYPE': pet_type_name,
            'PET_TEXT': pet_text,
            'PET_BODY_TYPE': pet_body_type,
            'BASIC_60_TOTAL': basic_60,
            'BASIC_80_TOTAL': basic_80,
            'CANCER_60_TOTAL': cancer_60
        }
        new_results.append(row)
        
        # 逐筆寫入 CSV
        write_row_to_csv(filename, row, fieldnames)
        
        # 試算間隔 1 秒（僅在實際試算時）
        if validate != 'N':
            time.sleep(1)
            print("試算間隔 1 秒後繼續...")

# 顯示前幾筆作為預覽（包含新舊）
print(f"\n試算完成！結果已逐筆輸出至 {filename}")
print(f"本次新增 {len(new_results)} 筆資料。")

# 顯示前幾筆作為預覽
print("\nCSV 預覽（前 5 筆）：")
for row in new_results[:5]:
    print(f"{row['PET_TYPE']}, {row['PET_TEXT']}, {row['PET_BODY_TYPE']}, {row['BASIC_60_TOTAL']}, {row['BASIC_80_TOTAL']}, {row['CANCER_60_TOTAL']}")
