# strategy.py (完整版)
"""
交易策略模組
生成訊號、持倉邏輯、報酬計算
"""

import pandas as pd
import numpy as np
import warnings
import logging
from config import (
    LONG_THRESHOLD, SHORT_THRESHOLD, COMMISSION_PER_TRADE, 
    CONTRACT_SIZE, ML_WINDOW, COMMISSION_PER_CONTRACT, STOP_LOSS_PCT)
from ml_utils import prepare_ml_data, train_model, generate_predictions

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore", category=pd.errors.SettingWithCopyWarning)

def optimize_thresholds(df_probs, model, scaler, cycle):
    """
    優化交易訊號的長/短閾值，以最大化淨報酬 (三分類模型版本)。
    df_probs 應包含 'Prob_Long' 和 'Prob_Short' 欄位。
    """
    logging.info("\nSTEP 4: 優化交易閾值 (三分類模型)...")
    best_net_return = -np.inf
    best_long_threshold = 0.0
    best_short_threshold = 0.0

    # 閾值範圍可以根據需求調整
    threshold_range = np.arange(0.2, 0.8, 0.025)

    if 'Prob_Long' not in df_probs.columns or 'Prob_Short' not in df_probs.columns:
        logging.warning("警告: df_probs 中缺少機率欄位，無法優化閾值。返回預設值。")
        return LONG_THRESHOLD, SHORT_THRESHOLD

    total_combinations = len(threshold_range) * len(threshold_range)
    logging.info(f"   將測試 {total_combinations} 種閾值組合...")

    for lt in threshold_range:
        for st in threshold_range:
            temp_df = df_probs.copy()
            
            # 根據長短倉機率生成訊號
            temp_df['Signal'] = 0
            long_cond = temp_df['Prob_Long'] > lt
            short_cond = temp_df['Prob_Short'] > st
            
            temp_df.loc[long_cond, 'Signal'] = 1
            temp_df.loc[short_cond, 'Signal'] = -1
            
            # 處理衝突：當長短訊號同時觸發，選擇機率更高的一方
            conflict_cond = long_cond & short_cond
            temp_df.loc[conflict_cond & (temp_df['Prob_Long'] >= temp_df['Prob_Short']), 'Signal'] = 1
            temp_df.loc[conflict_cond & (temp_df['Prob_Short'] > temp_df['Prob_Long']), 'Signal'] = -1

            # 如果沒有產生任何訊號，則跳過以節省時間
            if temp_df['Signal'].abs().sum() == 0:
                continue

            try:
                _, performance, _ = calculate_returns(temp_df, model, scaler, verbose=False)
                current_net_return = performance.get('總報酬率 (扣成本) (%)', -np.inf)

                if current_net_return > best_net_return:
                    best_net_return = current_net_return
                    best_long_threshold = lt
                    best_short_threshold = st
            except ValueError:
                pass # 忽略無交易發生的情況
            except Exception as e:
                # 減少不必要的錯誤日誌
                pass

    logging.info(f"   優化完成！最佳淨報酬: {best_net_return:.2f}%")
    logging.info(f"   最佳多單閾值: {best_long_threshold:.3f}, 最佳空單閾值: {best_short_threshold:.3f}")
    return best_long_threshold, best_short_threshold

def generate_signals(df, cycle="60m", train_pct=0.6, valid_pct=0.2):
    """
    生成雙向交易訊號 - 透過嚴格的訓練/驗證/測試分割 (三分類模型版本)。
    """
    logging.info(f"開始生成 ML 訊號 (訓練/驗證/測試分割)")
    
    train_len = int(len(df) * train_pct)
    valid_len = int(len(df) * valid_pct)
    
    train_df = df.iloc[:train_len]
    validation_df = df.iloc[train_len : train_len + valid_len]
    test_df = df.iloc[train_len + valid_len :]

    logging.info(f"   訓練集: {len(train_df)} 根 K-bar ({train_df.index.min()} -> {train_df.index.max()})")
    logging.info(f"   驗證集: {len(validation_df)} 根 K-bar ({validation_df.index.min()} -> {validation_df.index.max()})")
    logging.info(f"   測試集: {len(test_df)} 根 K-bar ({test_df.index.min()} -> {test_df.index.max()})")

    logging.info("\nSTEP 1: 準備訓練資料並訓練模型...")
    X_train, y_train, _, feature_names_train = prepare_ml_data(train_df)
    if len(X_train) == 0:
        raise ValueError("訓練資料不足，無法建立模型。")
    model, scaler, selector = train_model(X_train, y_train, feature_names_train)

    logging.info("\nSTEP 2: 在驗證集上生成預測並優化閾值...")
    X_valid, y_valid, df_valid_aligned, _ = prepare_ml_data(validation_df)
    
    if len(X_valid) == 0:
        logging.warning("警告：驗證集資料不足，無法優化閾值。將使用預設值。")
        optimal_long_threshold, optimal_short_threshold = (LONG_THRESHOLD, SHORT_THRESHOLD)
    else:
        preds_valid, probs_valid = generate_predictions(model, scaler, selector, X_valid)
        df_valid_aligned = df_valid_aligned.copy()
        df_valid_aligned['Predict'] = preds_valid
        # 根據模型的 classes_ 順序來賦值
        class_map = {v: i for i, v in enumerate(model.classes_)}
        df_valid_aligned['Prob_Short'] = probs_valid[:, class_map.get(-1, 0)]
        df_valid_aligned['Prob_Neutral'] = probs_valid[:, class_map.get(0, 1)]
        df_valid_aligned['Prob_Long'] = probs_valid[:, class_map.get(1, 2)]
        
        optimal_long_threshold, optimal_short_threshold = optimize_thresholds(df_valid_aligned, model, scaler, cycle)

    logging.info(f"\nSTEP 3: 在測試集上使用最佳閾值生成最終訊號...")
    logging.info(f"   使用最佳閾值：多單 {optimal_long_threshold:.3f}, 空單 {optimal_short_threshold:.3f}")

    X_test, y_test, df_test_aligned, _ = prepare_ml_data(test_df)
    
    if len(X_test) == 0:
        logging.warning("測試集資料不足，無法生成最終訊號。")
        return pd.DataFrame(), model, scaler, selector

    preds_test, probs_test = generate_predictions(model, scaler, selector, X_test)
    df_test_aligned = df_test_aligned.copy()
    df_test_aligned['Predict'] = preds_test
    class_map = {v: i for i, v in enumerate(model.classes_)}
    df_test_aligned['Prob_Short'] = probs_test[:, class_map.get(-1, 0)]
    df_test_aligned['Prob_Neutral'] = probs_test[:, class_map.get(0, 1)]
    df_test_aligned['Prob_Long'] = probs_test[:, class_map.get(1, 2)]
    
    logging.info(f"成功在 {len(df_test_aligned)} 筆測試資料上生成最終預測。")

    # 使用優化後的雙閾值生成訊號
    df_test_aligned['Signal'] = 0
    long_cond = df_test_aligned['Prob_Long'] > optimal_long_threshold
    short_cond = df_test_aligned['Prob_Short'] > optimal_short_threshold
    
    df_test_aligned.loc[long_cond, 'Signal'] = 1
    df_test_aligned.loc[short_cond, 'Signal'] = -1
    
    # 處理衝突
    conflict_cond = long_cond & short_cond
    df_test_aligned.loc[conflict_cond & (df_test_aligned['Prob_Long'] >= df_test_aligned['Prob_Short']), 'Signal'] = 1
    df_test_aligned.loc[conflict_cond & (df_test_aligned['Prob_Short'] > df_test_aligned['Prob_Long']), 'Signal'] = -1

    df_test_aligned['Position'] = df_test_aligned['Signal'].replace(0, method='ffill').fillna(0)
    df_test_aligned['Trade_Signal'] = df_test_aligned['Position'].diff()

    logging.info("最終測試集交易統計:")
    logging.info(f"   開多單：{len(df_test_aligned[df_test_aligned['Trade_Signal'] == 1])} 次 | 開空單：{len(df_test_aligned[df_test_aligned['Trade_Signal'] == -1])} 次")

    return df_test_aligned, model, scaler, selector

def calculate_returns(df, model=None, scaler=None, verbose=True):
    """使用迭代循環和止損機制，計算更真實的策略報酬"""
    if df.empty:
        raise ValueError("無訊號資料可供計算報酬")

    initial_capital = 100000
    capital = initial_capital
    position = 0
    entry_price = 0
    trades = []
    equity_curve = []

    if verbose:
        logging.info(f"交易成本設定：每筆交易 ${COMMISSION_PER_TRADE:.2f}")
        logging.info(f"風險管理：止損設定為 {STOP_LOSS_PCT}%")

    for i in range(len(df)):
        current_signal = df['Signal'].iloc[i]
        current_close = df['Close'].iloc[i]
        current_low = df['Low'].iloc[i]
        current_high = df['High'].iloc[i]
        exit_reason = ""

        if position == 1:
            stop_loss_price = entry_price * (1 - STOP_LOSS_PCT / 100)
            if current_low <= stop_loss_price:
                exit_price = stop_loss_price
                exit_reason = "Stop-Loss"
                position = 0
            elif current_signal == -1:
                exit_price = current_close
                exit_reason = "Signal Flip"
                position = -1
        elif position == -1:
            stop_loss_price = entry_price * (1 + STOP_LOSS_PCT / 100)
            if current_high >= stop_loss_price:
                exit_price = stop_loss_price
                exit_reason = "Stop-Loss"
                position = 0
            elif current_signal == 1:
                exit_price = current_close
                exit_reason = "Signal Flip"
                position = 1

        if exit_reason:
            pnl = (exit_price - entry_price) * CONTRACT_SIZE * (1 if trades[-1]['type'] == 'Long' else -1)
            net_pnl = pnl - (COMMISSION_PER_TRADE * 2)
            capital += net_pnl
            trades[-1].update({
                'exit_time': df.index[i],
                'exit_price': exit_price,
                'pnl': pnl,
                'net_pnl': net_pnl,
                'exit_reason': exit_reason
            })
            entry_price = 0

        if position == 0:
            if current_signal == 1:
                position = 1
                entry_price = current_close
                trades.append({'entry_time': df.index[i], 'entry_price': entry_price, 'type': 'Long'})
            elif current_signal == -1:
                position = -1
                entry_price = current_close
                trades.append({'entry_time': df.index[i], 'entry_price': entry_price, 'type': 'Short'})
        
        equity_curve.append(capital)

    # --- 績效計算 ---
    df['Equity'] = equity_curve
    df['Strategy_PnL'] = df['Equity'].diff().fillna(0)
    df['Returns'] = df['Equity'].pct_change()
    df['Cumulative_Strategy'] = df['Equity'] / initial_capital
    df['Cumulative_Market'] = (1 + df['Close'].pct_change()).cumprod()

    if not trades or all('exit_time' not in t for t in trades):
        if verbose: logging.info("回測期間無完整交易發生")
        df['Trade_Cost'] = 0.0
        return df, {}, pd.DataFrame()

    trade_df = pd.DataFrame([t for t in trades if 'exit_time' in t])
    
    df['Trade_Cost'] = 0.0
    for _, trade in trade_df.iterrows():
        if trade['exit_time'] in df.index:
            df.loc[trade['exit_time'], 'Trade_Cost'] = COMMISSION_PER_TRADE * 2

    total_return = (capital / initial_capital - 1) * 100
    market_return = (df['Close'].iloc[-1] / df['Close'].iloc[0] - 1) * 100
    sharpe_ratio = (df['Returns'].mean() / df['Returns'].std() * np.sqrt(252)) if df['Returns'].std() != 0 else 0
    max_drawdown = ((df['Equity'].cummax() - df['Equity']) / df['Equity'].cummax()).max() * 100

    win_trades = trade_df[trade_df['net_pnl'] > 0]
    loss_trades = trade_df[trade_df['net_pnl'] <= 0]
    win_rate = (len(win_trades) / len(trade_df) * 100) if len(trade_df) > 0 else 0
    
    long_trades = trade_df[trade_df['type'] == 'Long']
    short_trades = trade_df[trade_df['type'] == 'Short']
    long_win_rate = (len(long_trades[long_trades['net_pnl'] > 0]) / len(long_trades) * 100) if len(long_trades) > 0 else 0
    short_win_rate = (len(short_trades[short_trades['net_pnl'] > 0]) / len(short_trades) * 100) if len(short_trades) > 0 else 0

    performance = {
        '總報酬率 (扣成本) (%)': total_return,
        '市場報酬率 (%)': market_return,
        '超額報酬率 (%)': total_return - market_return,
        '夏普比率': sharpe_ratio,
        '最大回撤 (%)': max_drawdown,
        '總勝率 (%)': win_rate,
        '多單勝率 (%)': long_win_rate,
        '空單勝率 (%)': short_win_rate,
        '總交易次數': len(trade_df),
        '獲利交易': f"{len(win_trades)}/{len(trade_df)}",
        '平均每筆盈虧 ($)': trade_df['net_pnl'].mean(),
        '平均獲利 ($)': win_trades['net_pnl'].mean() if len(win_trades) > 0 else 0,
        '平均虧損 ($)': loss_trades['net_pnl'].mean() if len(loss_trades) > 0 else 0,
    }

    return df, performance, trade_df