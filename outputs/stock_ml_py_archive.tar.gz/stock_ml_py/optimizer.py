# optimizer.py
"""
對比測試：純訊號反轉 vs. 增加移動停利/停損
策略：1H MACD (優化參數 8, 32, 12)
"""

import pandas as pd
import numpy as np
import logging
import warnings

# 匯入專案的工具函式
from db_utils import fetch_data
from config import get_engine, COMMISSION_PER_TRADE, CONTRACT_SIZE, STOP_LOSS_PCT

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

def setup_logging():
    """設定日誌記錄器"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler("log/optimizer.log", mode='w', encoding='utf-8'),
            logging.StreamHandler()
        ]
    )

def calculate_macd(df, fast_period, slow_period, signal_period):
    """計算指定參數的 MACD"""
    df_macd = df.copy()
    ema_fast = df_macd['Close'].ewm(span=fast_period, adjust=False).mean()
    ema_slow = df_macd['Close'].ewm(span=slow_period, adjust=False).mean()
    df_macd['MACD'] = ema_fast - ema_slow
    df_macd['MACD_Signal'] = df_macd['MACD'].ewm(span=signal_period, adjust=False).mean()
    return df_macd

def run_signal_reversal_backtest(df, initial_capital=100000):
    """執行純訊號反轉的回測"""
    trades = []
    position = None
    entry_price = 0
    entry_time = None

    for timestamp, row in df.iterrows():
        signal = row['Signal']
        if position is None:
            position = signal
            entry_price = row['Close']
            entry_time = timestamp
            continue
        if signal != position:
            exit_price = row['Close']
            if position == 'BUY': pnl = (exit_price - entry_price) * CONTRACT_SIZE
            else: pnl = (entry_price - exit_price) * CONTRACT_SIZE
            net_pnl = pnl - (COMMISSION_PER_TRADE * 2)
            trades.append({'entry_time': entry_time, 'exit_time': timestamp, 'position_type': position, 'entry_price': entry_price, 'exit_price': exit_price, 'net_pnl': net_pnl})
            position = signal
            entry_price = row['Close']
            entry_time = timestamp
    if not trades: return {}
    trades_df = pd.DataFrame(trades)
    total_net_pnl = trades_df['net_pnl'].sum()
    total_return_pct = (total_net_pnl / initial_capital) * 100
    win_rate = (len(trades_df[trades_df['net_pnl'] > 0]) / len(trades_df) * 100) if not trades_df.empty else 0
    return {
        '總報酬率 (%)': total_return_pct, '總淨盈虧 ($)': total_net_pnl,
        '勝率 (%)': win_rate, '總交易次數': len(trades_df),
        '平均獲利 ($)': trades_df[trades_df['net_pnl'] > 0]['net_pnl'].mean(),
        '平均虧損 ($)': trades_df[trades_df['net_pnl'] <= 0]['net_pnl'].mean(),
    }

def run_backtest_with_trailing_stop(df, initial_capital=100000):
    """執行帶有移動停利/停損的回測"""
    trades = []
    position = None
    entry_price = 0
    entry_time = None
    peak_price = 0
    trough_price = float('inf')

    for timestamp, row in df.iterrows():
        signal = row['Signal']
        exit_reason = None

        if position is not None:
            if position == 'BUY':
                peak_price = max(peak_price, row['High'])
                trailing_stop_price = peak_price * (1 - STOP_LOSS_PCT / 100)
                if row['Low'] <= trailing_stop_price:
                    exit_price = trailing_stop_price
                    exit_reason = f"Trailing Stop"
            elif position == 'SELL':
                trough_price = min(trough_price, row['Low'])
                trailing_stop_price = trough_price * (1 + STOP_LOSS_PCT / 100)
                if row['High'] >= trailing_stop_price:
                    exit_price = trailing_stop_price
                    exit_reason = f"Trailing Stop"
            
            if not exit_reason and signal != position:
                exit_price = row['Close']
                exit_reason = "Signal Reversal"

            if exit_reason:
                if position == 'BUY': pnl = (exit_price - entry_price) * CONTRACT_SIZE
                else: pnl = (entry_price - exit_price) * CONTRACT_SIZE
                net_pnl = pnl - (COMMISSION_PER_TRADE * 2)
                trades.append({'entry_time': entry_time, 'exit_time': timestamp, 'position_type': position, 'entry_price': entry_price, 'exit_price': exit_price, 'net_pnl': net_pnl, 'exit_reason': exit_reason})
                position = None

        if position is None and signal in ['BUY', 'SELL']:
            position = signal
            entry_price = row['Close']
            entry_time = timestamp
            if position == 'BUY': peak_price = entry_price
            else: trough_price = entry_price

    if not trades: return {}
    trades_df = pd.DataFrame(trades)
    total_net_pnl = trades_df['net_pnl'].sum()
    total_return_pct = (total_net_pnl / initial_capital) * 100
    win_rate = (len(trades_df[trades_df['net_pnl'] > 0]) / len(trades_df) * 100) if not trades_df.empty else 0
    return {
        '總報酬率 (%)': total_return_pct, '總淨盈虧 ($)': total_net_pnl,
        '勝率 (%)': win_rate, '總交易次數': len(trades_df),
        '平均獲利 ($)': trades_df[trades_df['net_pnl'] > 0]['net_pnl'].mean(),
        '平均虧損 ($)': trades_df[trades_df['net_pnl'] <= 0]['net_pnl'].mean(),
    }

def run_comparison():
    """執行對比分析"""
    engine = get_engine()
    if engine is None: logging.error("無法連接資料庫，分析中止。"); return

    # 使用優化參數
    params = (8, 32, 12)
    cycle = '1h' # 更改為 1H 週期
    logging.info(f"--- 測試週期: {cycle}, MACD 參數: {params} ---")

    df_base = fetch_data(period="200d", cycle=cycle, limit=10000)
    if df_base is None: logging.error("無法獲取數據。 "); return

    df_macd = calculate_macd(df_base, params[0], params[1], params[2]).dropna()
    df_macd['Signal'] = np.where(df_macd['MACD'] > df_macd['MACD_Signal'], 'BUY', 'SELL')

    # 執行回測 A
    logging.info("\n--- 模式 A: 純訊號反轉策略 ---")
    perf_reversal = run_signal_reversal_backtest(df_macd)
    for key, value in perf_reversal.items():
        logging.info(f"{key:<25}: {value:.2f}")

    # 執行回測 B
    logging.info("\n--- 模式 B: 增加 2% 移動停利/停損 ---")
    perf_trailing_stop = run_backtest_with_trailing_stop(df_macd)
    for key, value in perf_trailing_stop.items():
        logging.info(f"{key:<25}: {value:.2f}")

if __name__ == "__main__":
    setup_logging()
    run_comparison()