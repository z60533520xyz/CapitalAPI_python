"""
字體診斷工具 v1.1 - 相容 Matplotlib 3.6.3
修復：API 相容性 + 語法錯誤
"""

import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import os
import matplotlib
from pathlib import Path
import tempfile

print("🔍 字體診斷工具 v1.1")
print(f"Matplotlib 版本: {matplotlib.__version__}")
print("=" * 50)

def diagnose_fonts():
    """完整診斷字體問題"""
    print("\n1️⃣ 檢查系統字體路徑...")
    
    # 常見 Windows 字體路徑
    font_paths = [
        r"C:\\Windows\\Fonts",
        os.path.expanduser(r"~\\AppData\\Local\\Microsoft\\Windows\\Fonts"),
    ]
    
    available_fonts = []
    for path in font_paths:
        if os.path.exists(path):
            print(f"✅ 字體資料夾存在: {path}")
            fonts = fm.findSystemFonts(path)
            print(f"   找到 {len(fonts)} 個字體檔案")
            available_fonts.extend(fonts)
        else:
            print(f"❌ 字體資料夾不存在: {path}")
    
    print(f"\n📊 總共找到 {len(available_fonts)} 個字體")
    
    # 搜尋中文字體
    print("\n2️⃣ 搜尋中文字體...")
    chinese_font_files = []
    chinese_keywords = ['sim', 'msjh', 'dfkai', 'mingliu', 'noto', 'wqy', 'kaiu', 'kai']
    
    for font_file in available_fonts:
        filename = os.path.basename(font_file).lower()
        for keyword in chinese_keywords:
            if keyword in filename:
                chinese_font_files.append(font_file)
                break
    
    print(f"🔤 找到 {len(chinese_font_files)} 個可能的中文字體：")
    for i, font_file in enumerate(chinese_font_files, 1):
        try:
            size_kb = os.path.getsize(font_file) / 1024
        except:
            size_kb = 0
        print(f"   {i:2d}. {os.path.basename(font_file):25s} ({size_kb:.0f}KB)")
    
    return chinese_font_files

def fix_matplotlib_cache():
    """修復 Matplotlib 快取（相容舊版）"""
    print("\n4️⃣ 修復 Matplotlib 快取...")
    
    # 舊版 Matplotlib 快取路徑（3.6.x）
    cache_dir = os.path.join(matplotlib.get_cachedir(), 'fontlist-v330.json')  # 舊版快取檔名
    print(f"   📁 預期快取位置: {cache_dir}")
    
    if os.path.exists(matplotlib.get_cachedir()):
        print(f"   ✅ Matplotlib 快取目錄存在: {matplotlib.get_cachedir()}")
        
        # 嘗試刪除舊快取（如果存在）
        if os.path.exists(cache_dir):
            try:
                os.remove(cache_dir)
                print("   🗑️  舊快取已刪除")
            except Exception as e:
                print(f"   ⚠️  刪除快取失敗: {e}")
        else:
            print("   ℹ️  未找到舊快取檔")
    else:
        print("   ❌ Matplotlib 快取目錄不存在")
    
    # 強制重建字體快取（通用方法）
    try:
        # 舊版方式：重新掃描字體
        fm._load_fontmanager(try_read_cache=False)
        print("   🔄 字體快取已重建")
    except Exception as e:
        print(f"   ⚠️  重建快取失敗: {e}")

def test_font_loading(font_path):
    """測試單一字體是否能被 Matplotlib 正確載入"""
    print(f"\n3️⃣ 測試字體: {os.path.basename(font_path)}")
    
    try:
        # 方法1：使用 FontProperties 載入
        font_prop = fm.FontProperties(fname=font_path)
        font_name = font_prop.get_name()
        print(f"   📄 FontProperties 成功: '{font_name}'")
        
        # 方法2：設定為預設字體
        plt.rcParams['font.sans-serif'] = [font_name]
        plt.rcParams['axes.unicode_minus'] = False
        
        # 方法3：測試繪圖
        fig, ax = plt.subplots(figsize=(8, 5))
        ax.set_facecolor('white')
        
        # 測試中文內容
        test_texts = [
            '台積電股價分析',
            '買入賣出訊號',
            'RSI 相對強弱指數',
            '2025年9月18日',
            'NT$ 1,285'
        ]
        
        y_pos = 0.8
        for text in test_texts:
            ax.text(0.05, y_pos, text, fontsize=14, ha='left', va='center', 
                    transform=ax.transAxes, fontproperties=font_prop)
            y_pos -= 0.15
        
        ax.set_title(f'字體測試: {font_name}', fontsize=16, fontproperties=font_prop)
        ax.axis('off')
        
        # 儲存測試圖片（使用臨時檔）
        with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as tmp_file:
            test_filename = tmp_file.name
        
        plt.savefig(test_filename, dpi=100, bbox_inches='tight')
        plt.close()
        
        # 檢查圖片
        if os.path.exists(test_filename):
            file_size = os.path.getsize(test_filename)
            print(f"   💾 測試圖片儲存: {test_filename}")
            print(f"   📏 檔案大小: {file_size} bytes")
            
            # 手動檢查是否包含中文（簡單檢查檔案大小 + 嘗試顯示）
            if file_size > 5000:  # 正常大小
                print("   ✅ 圖片生成成功！（檢查檔案是否顯示中文）")
                
                # 嘗試顯示圖片（如果支援）
                try:
                    plt.figure(figsize=(8, 5))
                    plt.imshow(plt.imread(test_filename))
                    plt.axis('off')
                    plt.title('測試圖片預覽')
                    plt.show(block=False)
                    print("   👁️  圖片預覽已顯示（檢查是否正常中文）")
                except:
                    print("   ⚠️  無法顯示預覽，但檔案生成成功")
                
                # 清理臨時檔
                os.unlink(test_filename)
                return True
            else:
                print("   ⚠️  圖片大小異常，可能無中文")
                os.unlink(test_filename)
                return False
        else:
            print("   ❌ 圖片儲存失敗")
            return False
            
    except Exception as e:
        print(f"   ❌ 載入失敗: {e}")
        return False

def find_best_chinese_font(chinese_fonts):
    """找出最佳中文字體"""
    print("\n5️⃣ 尋找最佳中文字體...")
    
    # 優先順序（根據你的清單）
    priority = [
        'NotoSansTC-VF.ttf',    # Google Noto：現代、清晰
        'msjh.ttc',             # 微軟正黑體：系統最佳
        'simhei.ttf',           # 黑體
        'dfkai-sb.ttf',         # 標楷體
        'simsun.ttc',           # 宋體
        'mingliu.ttc',          # 細明體
    ]
    
    for filename in priority:
        for font_path in chinese_fonts:
            if filename.lower() in os.path.basename(font_path).lower():
                print(f"   🎯 最佳字體: {os.path.basename(font_path)}")
                return font_path
    
    # 預設第一個
    if chinese_fonts:
        print(f"   ℹ️  使用第一個可用字體: {os.path.basename(chinese_fonts[0])}")
        return chinese_fonts[0]
    return None

# 主程式
if __name__ == "__main__":
    print("🚀 開始字體診斷...")
    
    # 步驟1：診斷系統字體
    chinese_fonts = diagnose_fonts()
    
    # 步驟2：修復快取
    fix_matplotlib_cache()
    
    # 步驟3：測試前3個中文字體（避免太久）
    print("\n6️⃣ 逐一測試中文字體（前3個）...")
    successful_fonts = []
    
    for i, font_path in enumerate(chinese_fonts[:3]):
        if test_font_loading(font_path):
            successful_fonts.append(font_path)
            print(f"   🎉 成功字體 #{i+1}: {os.path.basename(font_path)}")
            break  # 找到一個就停
    
    # 步驟4：最終解決方案
    print("\n" + "="*60)
    print("🎯 診斷結果與解決方案")
    print("="*60)
    
    if successful_fonts:
        best_font = successful_fonts[0]
        try:
            font_prop = fm.FontProperties(fname=best_font)
            font_name = font_prop.get_name()
        except:
            font_name = os.path.basename(best_font)
        
        print(f"✅ 最佳解決方案：使用字體 {os.path.basename(best_font)}")
        print(f"   字體名稱：{font_name}")
        print(f"\n📝 在 tsmc_trader.py 開頭加入以下程式碼：")
        print(f"import matplotlib.pyplot as plt")
        print(f"import matplotlib.font_manager as fm")
        print(f"font_path = r'{best_font}'  # 完整路徑")
        print(f"font_prop = fm.FontProperties(fname=font_path)")
        print(f"plt.rcParams['font.sans-serif'] = [font_prop.get_name()]")
        print(f"plt.rcParams['axes.unicode_minus'] = False")
        print(f"\n💡 測試：在 plot_analysis() 中使用 fontproperties=font_prop 繪製標題")
        
        # 最終測試
        print(f"\n🧪 最終系統測試...")
        plt.rcParams['font.sans-serif'] = [font_name]
        plt.rcParams['axes.unicode_minus'] = False
        
        fig, ax = plt.subplots(figsize=(10, 6))
        ax.text(0.5, 0.5, '🎉 成功！中文字體正常顯示\n台積電 (2330.TW) 量化分析系統\n報酬率: 32.54% | RSI: 86.1 (超買)', 
                fontsize=16, ha='center', va='center', transform=ax.transAxes,
                bbox=dict(boxstyle='round', facecolor='lightgreen', alpha=0.8))
        ax.set_title(f'最終測試：{font_name}', fontsize=14)
        ax.axis('off')
        plt.tight_layout()
        plt.show(block=False)  # 非阻塞顯示
        
        print("   👁️  檢查上方圖片是否正常顯示中文！")
        
    else:
        print("❌ 所有測試字體失敗")
        print("\n🔧 進階修復：")
        print("1. 重新安裝 Matplotlib: pip install --force-reinstall matplotlib==3.6.3")
        print("2. 下載並安裝 Noto Sans TC: https://fonts.google.com/noto/specimen/Noto+Sans+TC")
        print("   - 下載 NotoSansTC-Regular.ttf")
        print("   - 雙擊安裝到 Windows 字體資料夾")
        print("3. 使用英文標題（暫時方案）")
    
    print("\n🏁 診斷完成！執行後貼出結果（包含圖片描述），我幫你整合到 tsmc_trader.py")
