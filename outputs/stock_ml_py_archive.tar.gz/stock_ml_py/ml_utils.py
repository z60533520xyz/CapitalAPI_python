# ml_utils.py
"""
機器學習工具模組
訓練模型、生成預測
"""

import pandas as pd
import numpy as np
import logging
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score, classification_report
from sklearn.feature_selection import SelectKBest, f_classif
from config import (MLP_RANDOM_STATE, ML_FEATURES_K)

def train_model(features, labels, feature_names):
    """訓練 RandomForestClassifier 模型 (含 GridSearchCV 超參數調優) 並返回模型、scaler 及 selector"""
    if len(features) == 0:
        raise ValueError("ML 資料不足")
    
    # 將數據分為訓練集和測試集 (80/20)
    split_idx = int(len(features) * 0.8)
    X_train_df, X_test_df = features[:split_idx], features[split_idx:]
    y_train, y_test = labels[:split_idx], labels[split_idx:]

    # 特徵縮放
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train_df)
    X_test_scaled = scaler.transform(X_test_df)
    
    # 特徵選擇
    k_features = min(ML_FEATURES_K, X_train_scaled.shape[1])
    logging.info(f"執行特徵選擇：從 {X_train_scaled.shape[1]} 維選擇 {k_features} 維")
    selector = SelectKBest(f_classif, k=k_features)
    X_train_selected = selector.fit_transform(X_train_scaled, y_train)
    X_test_selected = selector.transform(X_test_scaled)
    
    selected_indices = selector.get_support(indices=True)
    selected_features = [feature_names[i] for i in selected_indices]
    logging.info(f"選擇出的最佳特徵: {selected_features}")

    logging.info("\n開始 RandomForestClassifier 超參數調優 (GridSearchCV)...")
    param_grid = {
        'n_estimators': [100, 200],
        'max_depth': [10, 20],
        'min_samples_leaf': [2, 4],
        'max_features': ['sqrt', 'log2']
    }
    
    # 使用 class_weight='balanced' 來處理數據不平衡問題
    rf_model = RandomForestClassifier(random_state=MLP_RANDOM_STATE, class_weight='balanced')
    
    grid_search = GridSearchCV(rf_model, param_grid, cv=3, scoring='accuracy', n_jobs=-1, verbose=1)
    grid_search.fit(X_train_selected, y_train)
    
    logging.info(f"調優完成！最佳參數: {grid_search.best_params_}")
    
    best_model = grid_search.best_estimator_
    
    # 在測試集上評估模型
    y_pred = best_model.predict(X_test_selected)
    test_acc = accuracy_score(y_test, y_pred)
    logging.info(f"\n模型在『測試集』上的最終表現:")
    logging.info(f"準確率 (Accuracy): {test_acc:.4f}")
    logging.info("\n分類報告 (Classification Report):\n" + classification_report(y_test, y_pred, target_names=['Short', 'Neutral', 'Long']))
    
    # 特徵重要性
    logging.info("\n--- 特徵重要性分析 ---")
    importances = best_model.feature_importances_
    feature_importance_df = pd.DataFrame({'Feature': selected_features, 'Importance': importances})
    feature_importance_df = feature_importance_df.sort_values(by='Importance', ascending=False)
    logging.info("\n" + feature_importance_df.to_string(index=False))

    # 重新使用全部數據訓練最終模型
    logging.info(f"\n使用全部 {len(features)} 筆資料與最佳參數重新訓練最終模型...")
    X_full_scaled = scaler.fit_transform(features)
    X_full_selected = selector.fit_transform(X_full_scaled, labels)
    
    final_model = RandomForestClassifier(**grid_search.best_params_, random_state=MLP_RANDOM_STATE, class_weight='balanced')
    final_model.fit(X_full_selected, labels)
    logging.info("模型已使用全部資料更新完畢。")
    
    return final_model, scaler, selector

def generate_predictions(model, scaler, selector, features):
    """生成預測"""
    features_scaled = scaler.transform(features)
    features_selected = selector.transform(features_scaled)
    preds = model.predict(features_selected)
    probs = model.predict_proba(features_selected)
    return preds, probs
