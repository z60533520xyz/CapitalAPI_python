import pandas as pd
import numpy as np
import logging
import warnings
import sys
import os

# 將專案根目錄加到 sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 匯入專案的工具函式
from db_utils import fetch_data
from common.indicators import calculate_indicators
from config import get_engine, SYMBOLS_CONFIG
from backtests.backtest_utils import setup_logging, calculate_performance, log_performance_report

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

def run_filtered_backtest(df, initial_capital=100000):
    """根據過濾後的 DataFrame 執行回測"""
    trades = []
    position = None
    entry_price = 0
    entry_time = None

    for timestamp, row in df.iterrows():
        signal = row['Final_Signal']
        current_price = row['Close_15m'] # Changed from 30m

        # 如果有開倉，檢查出場條件
        if position is not None:
            # 如果信號反轉或變為中性，則平倉
            if signal != position:
                exit_price = current_price
                pnl = (exit_price - entry_price) if position == 'BUY' else (entry_price - exit_price)
                net_pnl = pnl * SYMBOLS_CONFIG['CL0000']['CONTRACT_SIZE'] - (SYMBOLS_CONFIG['CL0000']['COMMISSION_PER_TRADE'] * 2)
                trades.append({
                    'entry_time': entry_time,
                    'exit_time': timestamp,
                    'position_type': position,
                    'entry_price': entry_price,
                    'exit_price': exit_price,
                    'pnl': pnl,
                    'net_pnl': net_pnl
                })
                position = None # 平倉

        # 如果沒有開倉 (或剛平倉) 且有信號，則開立新倉
        if position is None and signal != 'NEUTRAL':
            position = signal
            entry_price = current_price
            entry_time = timestamp
            
    return pd.DataFrame(trades)

def run_analysis():
    """執行分析"""
    engine = get_engine()
    if engine is None:
        logging.error("無法連接資料庫，分析中止。")
        return

    symbol_to_analyze = 'CL0000'
    initial_capital = 100000
    title = "15m MACD + 2h EMA 趨勢過濾策略"

    logging.info("=" * 60)
    logging.info(f"開始執行 {title}...")
    logging.info("=" * 60)

    try:
        data_frames = {}
        # 1. 獲取數據並計算指標
        for cycle in ['15m', '2h']: # Changed from 30m
            df = fetch_data(symbol=symbol_to_analyze, cycle=cycle, limit=10000, start_date='2024-11-09', end_date='2025-11-09')
            if df is None or df.empty:
                logging.warning(f"{cycle} 週期無資料，跳過.")
                return
            df_indicators = calculate_indicators(df).add_suffix(f'_{cycle}')
            data_frames[cycle] = df_indicators

        # 2. 合併數據框
        merged_df = pd.merge(data_frames['15m'], data_frames['2h'], left_index=True, right_index=True, how='left') # Changed from 30m
        merged_df.fillna(method='ffill', inplace=True)
        merged_df.dropna(inplace=True)

        # 3. 產生交易信號
        # 長期趨勢信號
        merged_df['Trend_2h'] = np.where(merged_df['EMA_50_2h'] > merged_df['EMA_200_2h'], 'BUY', 'SELL')
        # 短期動能信號
        merged_df['Signal_15m'] = np.where(merged_df['MACD_15m'] > merged_df['MACD_Signal_15m'], 'BUY', 'SELL') # Changed from 30m
        
        # 最終信號：兩者同向才持倉，否則空倉
        merged_df['Final_Signal'] = np.where(merged_df['Trend_2h'] == merged_df['Signal_15m'], merged_df['Trend_2h'], 'NEUTRAL') # Changed from 30m

        # 4. 執行回測
        trades_df = run_filtered_backtest(merged_df)

        # 5. 計算並記錄績效
        performance_report = calculate_performance(trades_df, initial_capital)
        log_performance_report(performance_report, "15m MACD + 2h EMA 趨勢過濾策略績效") # Changed from 30m

    except Exception as e:
        logging.error(f"回測執行時發生錯誤: {e}", exc_info=True)

if __name__ == "__main__":
    setup_logging("filtered_momentum_cl0000.log")
    run_analysis()