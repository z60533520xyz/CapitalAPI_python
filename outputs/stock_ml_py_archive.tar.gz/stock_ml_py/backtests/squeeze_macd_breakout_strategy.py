import pandas as pd
import numpy as np
import logging
import warnings
import sys
import os
import datetime

# 將專案根目錄加到 sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 匯入專案的工具函式
from db_utils import fetch_data
from common.indicators import calculate_indicators
from config import get_engine, SYMBOLS_CONFIG
from backtests.backtest_utils import setup_logging, calculate_performance, log_performance_report, run_signal_reversal_backtest

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

def run_analysis():
    """執行分析"""
    engine = get_engine()
    if engine is None:
        logging.error("無法連接資料庫，分析中止。")
        return

    symbol_to_analyze = 'CL0000' # 鎖定 CL0000
    cycle = '15m' # 使用 15 分鐘週期
    stop_loss_percent = 0.01 # 固定停損為 1.0%
    take_profit_percent = 0.015 # 固定停利為 1.5%
    initial_capital = 100000
    
    label = f"擠壓突破MACD確認策略 (擠壓閾值=0.9, SL={stop_loss_percent*100:.1f}%, TP={take_profit_percent*100:.1f}%)"

    logging.info("=" * 70)
    logging.info(f"開始執行 {symbol_to_analyze} 在 {cycle} 週期的回測 - {label}")
    logging.info("=" * 70)

    try:
        # 1. 獲取數據並計算指標
        end_date = datetime.date.today()
        start_date = end_date - datetime.timedelta(days=365)
        df = fetch_data(symbol=symbol_to_analyze, cycle=cycle, limit=10000, start_date=start_date.strftime('%Y-%m-%d'), end_date=end_date.strftime('%Y-%m-%d'))
        if df is None or df.empty:
            logging.warning(f"{symbol_to_analyze} 在 {cycle} 週期無資料，跳過。")
            return
        
        df_with_indicators = calculate_indicators(df).dropna()
        logging.info(f"計算指標後 DataFrame 大小: {len(df_with_indicators)}")

        # 2. 產生交易信號 (Squeeze Breakout with MACD Confirmation Strategy)
        squeeze_threshold = 0.9 # BB_Squeeze < 0.9 indicates a stricter squeeze

        # Squeeze Condition
        squeeze_condition = (df_with_indicators['BB_Squeeze'] < squeeze_threshold)

        # Entry Conditions (Long)
        long_breakout = (df_with_indicators['Close'] > df_with_indicators['BB_Upper'])
        long_macd_confirm = (df_with_indicators['MACD'] > df_with_indicators['MACD_Signal']) & \
                            (df_with_indicators['MACD'].shift(1) <= df_with_indicators['MACD_Signal'].shift(1))

        buy_signal = squeeze_condition & long_breakout & long_macd_confirm

        # Entry Conditions (Short)
        short_breakout = (df_with_indicators['Close'] < df_with_indicators['BB_Lower'])
        short_macd_confirm = (df_with_indicators['MACD'] < df_with_indicators['MACD_Signal']) & \
                             (df_with_indicators['MACD'].shift(1) >= df_with_indicators['MACD_Signal'].shift(1))

        sell_signal = squeeze_condition & short_breakout & short_macd_confirm

        df_with_indicators['Signal'] = np.where(buy_signal, 'BUY', np.where(sell_signal, 'SELL', None))
        
        logging.info(f"生成信號後 BUY 信號數量: {len(df_with_indicators[df_with_indicators['Signal'] == 'BUY'])}")
        logging.info(f"生成信號後 SELL 信號數量: {len(df_with_indicators[df_with_indicators['Signal'] == 'SELL'])}")
        df_with_indicators = df_with_indicators.dropna(subset=['Signal'])
        logging.info(f"移除無信號行後 DataFrame 大小: {len(df_with_indicators)}")

        # 3. 執行回測
        symbol_config = SYMBOLS_CONFIG[symbol_to_analyze]
        trades_df = run_signal_reversal_backtest(
            df_with_indicators, 
            stop_loss_percent=stop_loss_percent,
            take_profit_percent=take_profit_percent,
            COMMISSION_PER_TRADE=symbol_config['COMMISSION_PER_TRADE'],
            CONTRACT_SIZE=symbol_config['CONTRACT_SIZE']
        )

        # 4. 計算並記錄績效
        performance_report = calculate_performance(trades_df, initial_capital)
        log_performance_report(performance_report, f"{symbol_to_analyze} {cycle} 週期回測績效報告")

    except Exception as e:
        logging.error(f"處理 {symbol_to_analyze} 在 {cycle} 週期時發生錯誤: {e}", exc_info=True)

if __name__ == "__main__":
    setup_logging("squeeze_macd_breakout_strategy.log")
    run_analysis()
