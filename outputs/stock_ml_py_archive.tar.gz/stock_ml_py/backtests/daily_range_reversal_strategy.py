import pandas as pd
import numpy as np
import logging
import warnings
import sys
import os
import datetime

# 將專案根目錄加到 sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 匯入專案的工具函式
from db_utils import fetch_data
from common.indicators import calculate_indicators
from config import get_engine, SYMBOLS_CONFIG
from backtests.backtest_utils import setup_logging, calculate_performance, log_performance_report

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

def is_bearish_engulfing(df, current_index):
    """判斷是否為看跌吞噬形態"""
    if current_index < 1:
        return False

    prev_candle = df.iloc[current_index - 1]
    curr_candle = df.iloc[current_index]

    # 第一根是陽線 (前一根K棒的收盤價大於開盤價)
    is_prev_bullish = prev_candle['Close'] > prev_candle['Open']
    # 第二根是陰線 (當前K棒的收盤價小於開盤價)
    is_curr_bearish = curr_candle['Close'] < curr_candle['Open']

    # 第二根K棒完全吞噬第一根K棒
    engulfs = (curr_candle['Open'] > prev_candle['Close']) and \
              (curr_candle['Close'] < prev_candle['Open'])

    return is_prev_bullish and is_curr_bearish and engulfs

def run_backtest(df, initial_capital=100000, stop_loss_percent=0.02, trailing_stop_percent=0.005, commission_per_trade=10.0, contract_size=1000):
    """執行每日區間反轉策略的回測 (與C#邏輯同步)"""
    trades = []
    position = None  # 'BUY', 'SELL', or None
    entry_price = 0
    entry_time = None
    
    # 狀態變數 (與C#一致)
    is_currently_monitoring = False
    stop_trading_for_today = False
    touched_upper_band = False
    touched_lower_band = False
    
    # 移動停利用的變數
    highest_high_since_entry = 0
    lowest_low_since_entry = float('inf')

    for i, (timestamp, row) in enumerate(df.iterrows()):
        # 1. 監控時段邏輯 (與C#一致)
        monitoring_start_time = pd.to_datetime('18:30').time()
        monitoring_end_time = pd.to_datetime('17:00').time()
        current_time = timestamp.time()
        
        is_now_in_monitoring_time = (current_time >= monitoring_start_time) or (current_time < monitoring_end_time)

        if is_now_in_monitoring_time and not is_currently_monitoring:
            touched_upper_band = False
            touched_lower_band = False
            stop_trading_for_today = False
            logging.info(f"[{timestamp}] 開始新交易日監控")
        
        is_currently_monitoring = is_now_in_monitoring_time

        # 2. 出場邏輯 (與C#一致)
        if position is not None:
            exit_reason = None
            exit_price = None

            # 更新移動停利所需的高/低點
            if position == 'BUY':
                highest_high_since_entry = max(highest_high_since_entry, row['High'])
            elif position == 'SELL':
                lowest_low_since_entry = min(lowest_low_since_entry, row['Low'])

            # 檢查初始停損
            if stop_loss_percent > 0:
                if position == 'BUY':
                    initial_stop_price = entry_price * (1 - stop_loss_percent)
                    if row['Low'] <= initial_stop_price:
                        exit_price = initial_stop_price
                        exit_reason = 'Initial Stop'
                elif position == 'SELL':
                    initial_stop_price = entry_price * (1 + stop_loss_percent)
                    if row['High'] >= initial_stop_price:
                        exit_price = initial_stop_price
                        exit_reason = 'Initial Stop'
            
            # 檢查移動停利 (如果尚未觸發初始停損)
            if exit_reason is None and trailing_stop_percent > 0:
                if position == 'BUY':
                    trailing_stop_price = highest_high_since_entry * (1 - trailing_stop_percent)
                    if row['Low'] <= trailing_stop_price:
                        exit_price = trailing_stop_price
                        exit_reason = 'Trailing Stop'
                elif position == 'SELL':
                    trailing_stop_price = lowest_low_since_entry * (1 + trailing_stop_percent)
                    if row['High'] >= trailing_stop_price:
                        exit_price = trailing_stop_price
                        exit_reason = 'Trailing Stop'

            # 如果觸發了出場條件，則處理出場
            if exit_reason:
                pnl = (exit_price - entry_price) if position == 'BUY' else (entry_price - exit_price)
                net_pnl = (pnl * contract_size) - (commission_per_trade * 2) # 包含進場和出場的佣金
                trades.append({
                    'entry_time': entry_time,
                    'exit_time': timestamp,
                    'position_type': position,
                    'entry_price': entry_price,
                    'exit_price': exit_price,
                    'pnl': pnl * contract_size,
                    'net_pnl': net_pnl,
                    'exit_reason': exit_reason
                })
                logging.info(f"[{timestamp}] {position} EXIT at {exit_price:.2f} due to {exit_reason}. Net PnL: {net_pnl:.2f}")
                position = None
                stop_trading_for_today = True # 當日不再交易
                continue

        # 3. 進場邏輯 (與C#一致)
        if is_currently_monitoring and position is None and not stop_trading_for_today:
            # 更新布林通道觸及狀態
            if row['High'] >= row['BB_Upper']:
                touched_upper_band = True
            if row['Low'] <= row['BB_Lower']:
                touched_lower_band = True
            
            # 做空條件
            if touched_upper_band and is_bearish_engulfing(df, i):
                position = 'SELL'
                entry_price = row['Close']
                entry_time = timestamp
                lowest_low_since_entry = row['Low'] # 初始化移動停利用的低點
                touched_upper_band = False
                touched_lower_band = False
                logging.info(f"[{timestamp}] SELL ENTRY at {entry_price:.2f} (Bearish Engulfing)")
            
            # 做多條件
            elif touched_lower_band and df['RSI'].iloc[i-1] < 30 and row['RSI'] >= 30:
                position = 'BUY'
                entry_price = row['Close']
                entry_time = timestamp
                highest_high_since_entry = row['High'] # 初始化移動停利用的高點
                touched_upper_band = False
                touched_lower_band = False
                logging.info(f"[{timestamp}] BUY ENTRY at {entry_price:.2f} (RSI Reversal)")

    if not trades:
        logging.warning("無足夠交易可計算績效。返回空結果。")
        return {}, pd.DataFrame()

    trades_df = pd.DataFrame(trades)
    
    # 計算累積盈虧和最大回落
    trades_df['cumulative_pnl'] = trades_df['net_pnl'].cumsum()
    trades_df['peak_pnl'] = trades_df['cumulative_pnl'].expanding().max()
    trades_df['drawdown'] = trades_df['peak_pnl'] - trades_df['cumulative_pnl']
    max_drawdown = trades_df['drawdown'].max()

    total_net_pnl = trades_df['net_pnl'].sum()
    win_trades = trades_df[trades_df['net_pnl'] > 0]
    loss_trades = trades_df[trades_df['net_pnl'] <= 0]
    win_rate = (len(win_trades) / len(trades_df) * 100) if not trades_df.empty else 0

    performance = {
        '總淨盈虧 ($)': total_net_pnl,
        '總報酬率 (%)': (total_net_pnl / initial_capital) * 100,
        '總交易次數': len(trades_df),
        '勝率 (%)': win_rate,
        '獲利交易數': len(win_trades),
        '虧損交易數': len(loss_trades),
        '平均每筆交易盈虧 ($)': trades_df['net_pnl'].mean(),
        '平均獲利 ($)': win_trades['net_pnl'].mean() if not win_trades.empty else 0,
        '平均虧損 ($)': loss_trades['net_pnl'].mean() if not loss_trades.empty else 0,
        '最大回落 ($)': max_drawdown
    }
    return performance, trades_df

def run_analysis():
    """執行分析"""
    engine = get_engine()
    if engine is None:
        logging.error("無法連接資料庫，分析中止。")
        return

    symbol_to_analyze = 'CL0000'
    cycle = '30m'
    
    logging.info("=" * 70)
    logging.info(f"開始執行 {symbol_to_analyze} 在 {cycle} 週期的每日區間反轉策略回測")
    logging.info("=" * 70)
    
    try:
        end_date = datetime.date.today()
        start_date = end_date - datetime.timedelta(days=365)
        df = fetch_data(symbol=symbol_to_analyze, cycle=cycle, limit=20000, start_date=start_date.strftime('%Y-%m-%d'), end_date=end_date.strftime('%Y-%m-%d'))
        if df is None or df.empty:
            logging.warning(f"{symbol_to_analyze} 在 {cycle} 週期無資料，跳過。")
            return        
        df_with_indicators = calculate_indicators(df).dropna()
    
        symbol_config = SYMBOLS_CONFIG[symbol_to_analyze]
        # 使用與C#一致的參數
        performance_report, trades_df = run_backtest(
            df_with_indicators,
            stop_loss_percent=0.02, # C# StopLossPercent
            trailing_stop_percent=0.005, # C# TrailingStopPercent
            commission_per_trade=symbol_config['COMMISSION_PER_TRADE'],
            contract_size=symbol_config['CONTRACT_SIZE']
        )
    
        log_performance_report(performance_report, f"{symbol_to_analyze} {cycle} 週期回測績效報告")
    
    except Exception as e:
        logging.error(f"處理 {symbol_to_analyze} 在 {cycle} 週期時發生錯誤: {e}", exc_info=True)

if __name__ == "__main__":
    setup_logging("daily_range_reversal_strategy.log")
    run_analysis()
