import logging
import pandas as pd
import numpy as np
from datetime import datetime
import os

def setup_logging(log_file_name="backtest.log"):
    """
    設置日誌記錄器，將日誌輸出到文件和控制台。
    """
    # 使用檔案的絕對路徑來確保日誌目錄在正確的位置
    log_directory = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'logs')
    if not os.path.exists(log_directory):
        os.makedirs(log_directory)

    log_file_path = os.path.join(log_directory, log_file_name)

    # 清除現有的 handlers
    for handler in logging.root.handlers[:]:
        logging.root.removeHandler(handler)

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(log_file_path, mode='w', encoding='utf-8'),
            logging.StreamHandler()
        ]
    )

def calculate_performance(trades_df, initial_capital=100000):
    """
    計算回測績效指標。
    """
    if trades_df.empty:
        logging.info("無足夠交易可計算績效。")
        return {}

    # 計算累積盈虧
    trades_df['cumulative_pnl'] = trades_df['net_pnl'].cumsum()
    trades_df['peak_pnl'] = trades_df['cumulative_pnl'].expanding().max()
    trades_df['drawdown'] = trades_df['peak_pnl'] - trades_df['cumulative_pnl']
    max_drawdown = trades_df['drawdown'].max()

    win_trades = trades_df[trades_df['net_pnl'] > 0]
    loss_trades = trades_df[trades_df['net_pnl'] <= 0]

    total_net_pnl = trades_df['net_pnl'].sum()
    total_return_pct = (total_net_pnl / initial_capital) * 100
    win_rate = (len(win_trades) / len(trades_df) * 100) if not trades_df.empty else 0

    performance = {
        '總淨盈虧 ($)': total_net_pnl,
        '總報酬率 (%)': total_return_pct,
        '總交易次數': len(trades_df),
        '勝率 (%)': win_rate,
        '獲利交易次數': len(win_trades),
        '虧損交易次數': len(loss_trades),
        '平均每筆交易淨盈虧 ($)': trades_df['net_pnl'].mean(),
        '平均獲利 ($)': win_trades['net_pnl'].mean() if not win_trades.empty else 0,
        '平均虧損 ($)': loss_trades['net_pnl'].mean() if not loss_trades.empty else 0,
        '最大回落 ($)': max_drawdown
    }
    return performance

def log_performance_report(performance_report, title="回測績效報告"):
    """
    將績效報告記錄到日誌。
    """
    logging.info(f"--- {title} ---")
    if not performance_report:
        logging.info("無績效報告可顯示。")
        return

    for key, value in performance_report.items():
        if isinstance(value, (float, np.floating)):
            logging.info(f"{key:<25}: {value:.2f}")
        else:
            logging.info(f"{key:<25}: {value}")
    logging.info("-" * 30)

def run_signal_reversal_backtest(df, take_profit_percent=None, stop_loss_percent=None, trailing_stop_percent=None, COMMISSION_PER_TRADE=10.0, CONTRACT_SIZE=1000):
    """根據訊號 DataFrame 執行訊號反轉的回測，並加入停損停利"""
    logging.info(f"進入回測函數，DataFrame 大小: {len(df)}")
    trades = []
    position = None
    entry_price = 0
    entry_time = None
    entry_volume = 0
    max_profit_during_current_trade = 0
    max_loss_during_current_trade = 0

    for timestamp, row in df.iterrows():
        signal = row['Signal']
        current_price = row['Close']
        exit_reason = None

        logging.debug(f"  時間: {timestamp}, 信號: {signal}, 當前倉位: {position}, 當前價格: {current_price}")

        # 如果有開倉，檢查出場條件
        if position is not None:
            # 計算當前浮動盈虧並更新最高獲利和最大虧損
            current_floating_pnl = 0
            if position == 'BUY':
                current_floating_pnl = (current_price - entry_price) * CONTRACT_SIZE
            elif position == 'SELL':
                current_floating_pnl = (entry_price - current_price) * CONTRACT_SIZE
            max_profit_during_current_trade = max(max_profit_during_current_trade, current_floating_pnl)
            max_loss_during_current_trade = min(max_loss_during_current_trade, current_floating_pnl)

            logging.debug(f"  浮動盈虧: {current_floating_pnl:.2f}, 最大獲利: {max_profit_during_current_trade:.2f}, 最大虧損: {max_loss_during_current_trade:.2f}")

            # 檢查停利條件
            if take_profit_percent and current_floating_pnl >= (entry_price * CONTRACT_SIZE * take_profit_percent):
                exit_reason = 'Take Profit'
            # 檢查停損條件
            elif stop_loss_percent and current_floating_pnl <= -(entry_price * CONTRACT_SIZE * stop_loss_percent):
                exit_reason = 'Stop Loss'
            # 檢查移動停損 (僅在盈利時啟用)
            elif trailing_stop_percent and current_floating_pnl > 0:
                # 計算移動停損價格
                if position == 'BUY':
                    trailing_stop_level = entry_price + (max_profit_during_current_trade / CONTRACT_SIZE) * (1 - trailing_stop_percent)
                    if current_price <= trailing_stop_level:
                        exit_reason = 'Trailing Stop'
                elif position == 'SELL':
                    trailing_stop_level = entry_price - (max_profit_during_current_trade / CONTRACT_SIZE) * (1 - trailing_stop_percent)
                    if current_price >= trailing_stop_level:
                        exit_reason = 'Trailing Stop'
            # 檢查信號反轉
            elif signal != position:
                exit_reason = 'Signal Reversal'

            if exit_reason:
                logging.debug(f"  出場原因: {exit_reason}")
                exit_price = current_price

                if position == 'BUY':
                    pnl = (exit_price - entry_price) * CONTRACT_SIZE
                else:  # SELL
                    pnl = (entry_price - exit_price) * CONTRACT_SIZE

                net_pnl = pnl - (COMMISSION_PER_TRADE * 2)

                trades.append({
                    'entry_time': entry_time,
                    'exit_time': timestamp,
                    'position_type': position,
                    'entry_price': entry_price,
                    'exit_price': exit_price,
                    'pnl': pnl,
                    'net_pnl': net_pnl,
                    'max_profit_during_trade': max_profit_during_current_trade,
                    'max_loss_during_trade': max_loss_during_current_trade,
                    'exit_reason': exit_reason,
                    'entry_volume': entry_volume
                })
                position = None  # 平倉
                logging.debug(f"  交易記錄: {trades[-1]}")

        # 如果沒有開倉 (或剛平倉) 且有信號，則開立新倉
        if position is None and signal is not None:
            position = signal
            entry_price = current_price
            entry_time = timestamp
            entry_volume = row['Volume']
            max_profit_during_current_trade = 0
            max_loss_during_current_trade = 0
            logging.debug(f"  開立新倉: {position} @ {entry_price}")

    if not trades:
        logging.info("無足夠交易可計算績效。" )
        return pd.DataFrame()

    return pd.DataFrame(trades)
