# simple_momentum_backtest.py
"""
對單一週期的雙通道策略進行回測 (布林通道 + 凱勒通道複合策略)。
策略：根據布林通道和凱勒通道的複合信號進行交易。
"""

import pandas as pd
import numpy as np
import logging
import warnings
import sys
import os
import datetime

# 將專案根目錄加到 sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 匯入專案的工具函式
from db_utils import fetch_data
from common.indicators import calculate_indicators
from config import get_engine, SYMBOLS_CONFIG

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

def setup_logging():
    """設定日誌記錄器"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler("momentum_backtest.log", mode='w', encoding='utf-8'),
            logging.StreamHandler()
        ]
    )

def run_signal_reversal_backtest(df, contract_size, commission_per_trade, initial_capital=100000, stop_loss_percent=None):
    """根據訊號 DataFrame 執行訊號反轉的回測，並加入停損停利"""
    logging.info(f"進入回測函數，DataFrame 大小: {len(df)}")
    trades = []
    position = None
    entry_price = 0
    entry_time = None

    for timestamp, row in df.iterrows():
        signal = row['Signal']
        current_price = row['Close']
        exit_reason = None

        if position is not None:
            pnl = (current_price - entry_price) * contract_size if position == 'BUY' else (entry_price - current_price) * contract_size
            
            stop_loss_pnl = -(entry_price * contract_size * stop_loss_percent) if stop_loss_percent else None

            if stop_loss_pnl is not None and pnl <= stop_loss_pnl:
                exit_reason = 'Stop Loss'
            elif signal != position:
                exit_reason = 'Signal Reversal'

            if exit_reason:
                exit_price = current_price
                final_pnl = (exit_price - entry_price) * contract_size if position == 'BUY' else (entry_price - exit_price) * contract_size
                net_pnl = final_pnl - commission_per_trade

                trades.append({
                    'entry_time': entry_time,
                    'exit_time': timestamp,
                    'position_type': position,
                    'entry_price': entry_price,
                    'exit_price': exit_price,
                    'pnl': final_pnl,
                    'net_pnl': net_pnl,
                    'exit_reason': exit_reason
                })
                position = None

        if position is None and signal is not None:
            position = signal
            entry_price = current_price
            entry_time = timestamp

    if not trades:
        logging.info("無足夠交易可計算績效 ويعود")
        return {}, pd.DataFrame()

    trades_df = pd.DataFrame(trades)
    trades_df['cumulative_pnl'] = trades_df['net_pnl'].cumsum()
    trades_df['peak_pnl'] = trades_df['cumulative_pnl'].expanding().max()
    trades_df['drawdown'] = trades_df['peak_pnl'] - trades_df['cumulative_pnl']
    max_drawdown = trades_df['drawdown'].max()

    win_trades = trades_df[trades_df['net_pnl'] > 0]
    loss_trades = trades_df[trades_df['net_pnl'] <= 0]
    
    total_net_pnl = trades_df['net_pnl'].sum()
    win_rate = (len(win_trades) / len(trades_df) * 100) if not trades_df.empty else 0

    performance = {
        '總淨盈虧 ($)': total_net_pnl,
        '總報酬率 (%)': (total_net_pnl / initial_capital) * 100,
        '總交易次數': len(trades_df),
        '勝率 (%)': win_rate,
        '平均每筆交易盈虧 ($)': trades_df['net_pnl'].mean(),
        '最大回落 ($)': max_drawdown
    }
    return performance, trades_df

def run_analysis():
    """執行分析"""
    engine = get_engine()
    if engine is None:
        logging.error("無法連接資料庫，分析中止。")
        return

    symbol = 'ES0000'
    cycles_to_analyze = ['5m', '30m', '60m']
    stop_loss_percent = 0.01 # 使用預設停損值

    symbol_config = SYMBOLS_CONFIG.get(symbol)
    if not symbol_config:
        logging.warning(f"找不到標的 {symbol} 的設定，跳過。")
        return

    for cycle in cycles_to_analyze:
        cycle_params = symbol_config['CYCLES'].get(cycle)
        if not cycle_params:
            logging.warning(f"找不到標的 {symbol} 週期 {cycle} 的設定，跳過。")
            continue

        logging.info("=" * 60)
        logging.info(f"開始執行 {symbol} ({symbol_config['SYMBOL_DISPLAY']}) {cycle} 週期回測...")
        logging.info(f"使用參數: KC Period={cycle_params['KC_PERIOD']}, KC Multiplier={cycle_params['KC_MULTIPLIER']}")
        logging.info(f"固定停損值: {stop_loss_percent*100:.1f}%")
        logging.info("=" * 60)

        try:
            end_date = datetime.date.today()
            start_date = end_date - datetime.timedelta(days=365)
            df = fetch_data(symbol=symbol, cycle=cycle, limit=10000, start_date=start_date.strftime('%Y-%m-%d'), end_date=end_date.strftime('%Y-%m-%d'))
            if df is None or df.empty:
                logging.warning(f"{cycle} 週期無資料，跳過。")
                continue
            
            df_with_indicators = calculate_indicators(df, kc_period=cycle_params['KC_PERIOD'], kc_multiplier=cycle_params['KC_MULTIPLIER']).dropna()

            buy_condition = (df_with_indicators['Close'] > df_with_indicators['BB_Upper']) & (df_with_indicators['Close'] > df_with_indicators['KC_Upper'])
            sell_condition = (df_with_indicators['Close'] < df_with_indicators['BB_Lower']) & (df_with_indicators['Close'] < df_with_indicators['KC_Lower'])

            df_with_indicators['Signal'] = np.where(buy_condition, 'BUY', np.where(sell_condition, 'SELL', None))
            
            signal_df = df_with_indicators.dropna(subset=['Signal'])

            performance_report, _ = run_signal_reversal_backtest(
                signal_df,
                contract_size=symbol_config['CONTRACT_SIZE'],
                commission_per_trade=symbol_config['COMMISSION_PER_TRADE'],
                stop_loss_percent=stop_loss_percent
            )

            logging.info(f"--- {symbol} {cycle} 週期回測績效報告 ---")
            if not performance_report:
                logging.info("無足夠交易可計算績效。\n")
            else:
                for key, value in performance_report.items():
                    logging.info(f"{key:<25}: {value:.2f}")
                logging.info("\n")

        except Exception as e:
            logging.error(f"處理 {symbol} {cycle} 週期時發生錯誤: {e}", exc_info=True)

if __name__ == "__main__":
    setup_logging()
    run_analysis()