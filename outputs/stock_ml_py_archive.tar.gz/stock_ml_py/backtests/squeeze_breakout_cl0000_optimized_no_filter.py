import pandas as pd
import numpy as np
import logging
import warnings
import sys
import os
import datetime

# 將專案根目錄加到 sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 匯入專案的工具函式
from db_utils import fetch_data
from common.indicators import calculate_indicators
from config import get_engine, SYMBOLS_CONFIG
from backtests.backtest_utils import setup_logging, calculate_performance, log_performance_report, run_signal_reversal_backtest

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

def analyze_trade_distributions(trades_df):
    """分析交易分佈及中位數"""
    if trades_df.empty:
        logging.info("無交易數據可供分析。" )
        return

    buy_trades = trades_df[trades_df['position_type'] == 'BUY']
    sell_trades = trades_df[trades_df['position_type'] == 'SELL']

    logging.info("--- 交易分佈分析報告 ---")

    # 買入交易分析
    if not buy_trades.empty:
        logging.info("--- 買入交易 (BUY Trades) ---")
        logging.info(f"買入交易總數: {len(buy_trades)}")
        logging.info(f"買入交易平均淨盈虧: {buy_trades['net_pnl'].mean():.2f}")
    else:
        logging.info("無買入交易數據。" )

    # 賣出交易分析
    if not sell_trades.empty:
        logging.info("--- 賣出交易 (SELL Trades) ---")
        logging.info(f"賣出交易總數: {len(sell_trades)}")
        logging.info(f"賣出交易平均淨盈虧: {sell_trades['net_pnl'].mean():.2f}")
    else:
        logging.info("無賣出交易數據。" )

def run_analysis():
    """執行分析"""
    engine = get_engine()
    if engine is None:
        logging.error("無法連接資料庫，分析中止。" )
        return

    symbol_to_analyze = 'CL0000' # 鎖定 CL0000
    cycle = '15m' # 固定為 15m 週期
    stop_loss_percent = 0.01 # 固定停損為 1.0%
    take_profit_percent = 0.015 # 固定停利為 1.5%
    trailing_stop_percent = 0.008 # 移動停損為 0.8%
    initial_capital = 100000
    label = f"擠壓突破策略 (SL={stop_loss_percent*100:.1f}%, TP={take_profit_percent*100:.1f}%, TS={trailing_stop_percent*100:.1f}%)"

    logging.info("=" * 70)
    logging.info(f"開始執行 {symbol_to_analyze} 在 {cycle} 週期的回測 - {label}")
    logging.info("=" * 70)

    try:
        # 1. 獲取數據並計算指標
        end_date = datetime.date.today()
        start_date = end_date - datetime.timedelta(days=365)
        df = fetch_data(symbol=symbol_to_analyze, cycle=cycle, limit=10000, start_date=start_date.strftime('%Y-%m-%d'), end_date=end_date.strftime('%Y-%m-%d'))
        if df is None or df.empty:
            logging.warning(f"{symbol_to_analyze} 在 {cycle} 週期無資料，跳過。" )
            return
        
        # 將原始 K 線數據保存到 CSV 檔案，以便與 C# 數據進行比較
        df.to_csv("outputs/python_kline_data.csv", index=False)
        logging.info("Python K 線數據已保存到 outputs/python_kline_data.csv")        
        df_with_indicators = calculate_indicators(df).dropna()

        # --- START: ADDED FOR DEBUGGING ---
        # Prepare the DataFrame for indicator export
        indicator_df = df_with_indicators.copy()
        indicator_df['squeeze_on'] = (indicator_df['BB_Upper'] < indicator_df['KC_Upper']) & (indicator_df['BB_Lower'] > indicator_df['KC_Lower'])

        # Select and rename columns to match C# output
        columns_to_export = {
            'Open': 'Open',
            'High': 'High',
            'Low': 'Low',
            'Close': 'Close',
            'Volume': 'Volume',
            'BB_Upper': 'BBUB',
            'BB_Lower': 'BBLB',
            'KC_Upper': 'KCUB',
            'KC_Lower': 'KCLB',
            'KC_Middle': 'KCMB',
            'squeeze_on': 'squeeze_on'
        }
        export_df = indicator_df[list(columns_to_export.keys())].rename(columns=columns_to_export)

        # Save to CSV, including the date index
        export_df.to_csv("outputs/python_indicator_data.csv", index=True, date_format='%Y-%m-%d %H:%M:%S')
        logging.info("Python Indicator data successfully saved to outputs/python_indicator_data.csv")        # --- END: ADDED FOR DEBUGGING ---
        
        logging.info(f"計算指標後 DataFrame 大小: {len(df_with_indicators)}")
        logging.info(f"指標計算後資料 (前5筆):\n{df_with_indicators.head().to_string()}")

        # 2. 產生交易信號 (擠壓突破策略)
        squeeze_on = (df_with_indicators['BB_Upper'] < df_with_indicators['KC_Upper']) & (df_with_indicators['BB_Lower'] > df_with_indicators['KC_Lower'])

        buy_condition = squeeze_on.shift(1) & (df_with_indicators['Close'] > df_with_indicators['KC_Upper'])
        sell_condition = squeeze_on.shift(1) & (df_with_indicators['Close'] < df_with_indicators['KC_Lower'])

        df_with_indicators['Signal'] = np.where(buy_condition, 'BUY', np.where(sell_condition, 'SELL', None))
        logging.info(f"生成信號後 BUY 信號數量: {len(df_with_indicators[df_with_indicators['Signal'] == 'BUY'])}")
        logging.info(f"生成信號後 SELL 信號數量: {len(df_with_indicators[df_with_indicators['Signal'] == 'SELL'])}")
        
        # 顯示前20個信號
        signal_df = df_with_indicators[df_with_indicators['Signal'].notna()]
        logging.info(f"前20個交易信號:\n{signal_df.head(20).to_string()}")

        df_with_indicators = df_with_indicators.dropna(subset=['Signal'])
        logging.info(f"移除無信號行後 DataFrame 大小: {len(df_with_indicators)}")

        # 3. 執行回測
        symbol_config = SYMBOLS_CONFIG[symbol_to_analyze]
        # 暫時硬編碼 COMMISSION_PER_TRADE 和 CONTRACT_SIZE 以與 C# 環境對齊
        symbol_config['COMMISSION_PER_TRADE'] = 7
        symbol_config['CONTRACT_SIZE'] = 1000
        trades_df = run_signal_reversal_backtest(
            df_with_indicators, 
            stop_loss_percent=stop_loss_percent,
            take_profit_percent=take_profit_percent,
            trailing_stop_percent=trailing_stop_percent,
            COMMISSION_PER_TRADE=symbol_config['COMMISSION_PER_TRADE'],
            CONTRACT_SIZE=symbol_config['CONTRACT_SIZE']
        )

        # 記錄完整交易歷史
        if not trades_df.empty:
            logging.info(f"完整交易歷史:\n{trades_df.to_string()}")

        # 4. 計算並記錄績效
        performance_report = calculate_performance(trades_df, initial_capital)
        log_performance_report(performance_report, f"{symbol_to_analyze} {cycle} 週期回測績效報告")

        # 5. 分析交易分佈
        analyze_trade_distributions(trades_df)

        # 6. 按小時分析交易績效
        if not trades_df.empty:
            trades_df['entry_hour'] = trades_df['entry_time'].dt.hour
            hourly_performance = trades_df.groupby('entry_hour').agg(
                total_net_pnl=('net_pnl', 'sum'),
                total_trades=('net_pnl', 'count'),
                win_trades=('net_pnl', lambda x: (x > 0).sum()),
                loss_trades=('net_pnl', lambda x: (x <= 0).sum())
            )
            hourly_performance['win_rate'] = (hourly_performance['win_trades'] / hourly_performance['total_trades']) * 100

            logging.info("\n--- 按小時交易績效報告 ---")
            for hour, data in hourly_performance.iterrows():
                logging.info(f"小時: {hour:02d} - 總淨盈虧: {data['total_net_pnl']:.2f}, 總交易: {int(data['total_trades'])}, 勝率: {data['win_rate']:.2f}%")
        else:
            logging.info("無交易數據可供按小時分析。" )

        # 7. 分析開倉時交易量與交易績效關係
        analyze_volume_performance(trades_df)

    except Exception as e:
        logging.error(f"處理 {symbol_to_analyze} 在 {cycle} 週期時發生錯誤: {e}", exc_info=True)

def analyze_volume_performance(trades_df):
    """分析開倉時交易量與交易績效的關係"""
    if trades_df.empty:
        logging.info("無交易數據可供分析交易量與績效的關係。" )
        return

    # 將交易量分箱
    trades_df['volume_bin'] = pd.qcut(trades_df['entry_volume'], q=5, labels=False, duplicates='drop')

    volume_performance = trades_df.groupby('volume_bin').agg(
        total_net_pnl=('net_pnl', 'sum'),
        total_trades=('net_pnl', 'count'),
        win_trades=('net_pnl', lambda x: (x > 0).sum()),
        loss_trades=('net_pnl', lambda x: (x <= 0).sum())
    )
    volume_performance['win_rate'] = (volume_performance['win_trades'] / volume_performance['total_trades']) * 100

    logging.info("\n--- 按開倉交易量分箱的績效報告 ---")
    for bin_label, data in volume_performance.iterrows():
        min_vol = trades_df[trades_df['volume_bin'] == bin_label]['entry_volume'].min()
        max_vol = trades_df[trades_df['volume_bin'] == bin_label]['entry_volume'].max()
        logging.info(f"交易量範圍: {min_vol}-{max_vol} - 總淨盈虧: {data['total_net_pnl']:.2f}, 總交易: {int(data['total_trades'])}, 勝率: {data['win_rate']:.2f}%")

if __name__ == "__main__":
    setup_logging("squeeze_breakout_cl0000_optimized_no_filter.log")
    run_analysis()
