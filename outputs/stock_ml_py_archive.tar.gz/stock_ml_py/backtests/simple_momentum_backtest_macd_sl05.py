# simple_momentum_backtest.py
"""
對單一週期的 MACD 動能策略進行回測。
策略：MACD > Signal (macd_power > 0) 則做多，否則做空。
"""

import pandas as pd
import numpy as np
import logging
import warnings
import sys
import os
import datetime

# 將專案根目錄加到 sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 匯入專案的工具函式
from db_utils import fetch_data
from common.indicators import calculate_indicators
from config import get_engine, COMMISSION_PER_TRADE, CONTRACT_SIZE

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

def setup_logging():
    """設定日誌記錄器"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler("simple_momentum.log", mode='w', encoding='utf-8'),
            logging.StreamHandler()
        ]
    )

def run_signal_reversal_backtest(df, initial_capital=100000, fixed_sl_percent=None):
    """根據訊號 DataFrame 執行訊號反轉的回測"""
    trades = []
    position = None
    entry_price = 0
    entry_time = None
    max_profit_during_current_trade = 0
    max_loss_during_current_trade = 0 # Initialize here

    for timestamp, row in df.iterrows():
        signal = row['Signal']
        
        # 如果沒有倉位，則根據當前信號開倉
        if position is None:
            position = signal
            entry_price = row['Close']
            entry_time = timestamp
            max_profit_during_current_trade = 0 # Reset for new trade
            max_loss_during_current_trade = 0 # Reset for new trade
            continue
        
        # 計算當前浮動盈虧並更新最高獲利和最大虧損
        current_floating_pnl = 0
        if position == 'BUY':
            current_floating_pnl = (row['Close'] - entry_price) * CONTRACT_SIZE
        elif position == 'SELL':
            current_floating_pnl = (entry_price - row['Close']) * CONTRACT_SIZE
        max_profit_during_current_trade = max(max_profit_during_current_trade, current_floating_pnl)
        max_loss_during_current_trade = min(max_loss_during_current_trade, current_floating_pnl) # Update max loss
        # 檢查固定停損
        exit_reason_sl = None
        if fixed_sl_percent is not None and position is not None:
            if position == 'BUY' and row['Close'] <= entry_price * (1 - fixed_sl_percent):
                exit_reason_sl = 'Fixed Stop Loss (BUY)'
            elif position == 'SELL' and row['Close'] >= entry_price * (1 + fixed_sl_percent):
                exit_reason_sl = 'Fixed Stop Loss (SELL)'
        
        if exit_reason_sl is not None:
            exit_price = row['Close']
            if position == 'BUY':
                pnl = (exit_price - entry_price) * CONTRACT_SIZE
            else: # SELL
                pnl = (entry_price - exit_price) * CONTRACT_SIZE
            
            net_pnl = pnl - (COMMISSION_PER_TRADE * 2)

            trades.append({
                'entry_time': entry_time,
                'exit_time': timestamp,
                'position_type': position,
                'entry_price': entry_price,
                'exit_price': exit_price,
                'pnl': pnl,
                'net_pnl': net_pnl,
                'max_profit_during_trade': max_profit_during_current_trade,
                'max_loss_during_trade': max_loss_during_current_trade,
                'exit_reason': exit_reason_sl
            })
            # 平倉後，清空倉位
            position = None
            entry_price = 0
            entry_time = None
            max_profit_during_current_trade = 0
            max_loss_during_current_trade = 0
            continue # Move to next iteration after closing trade
        # 如果信號反轉，則平倉並開立新倉
        if signal != position:
            exit_price = row['Close']
            
            if position == 'BUY':
                pnl = (exit_price - entry_price) * CONTRACT_SIZE
            else: # SELL
                pnl = (entry_price - exit_price) * CONTRACT_SIZE
            
            net_pnl = pnl - (COMMISSION_PER_TRADE * 2)

            trades.append({
                'entry_time': entry_time,
                'exit_time': timestamp,
                'position_type': position,
                'entry_price': entry_price,
                'exit_price': exit_price,
                'pnl': pnl,
                'net_pnl': net_pnl,
                'max_profit_during_trade': max_profit_during_current_trade,
                'max_loss_during_trade': max_loss_during_current_trade, # Add this line
                'exit_reason': 'Signal Reversal'
            })
            
            # 開立新倉
            position = signal
            entry_price = row['Close']
            entry_time = timestamp
            max_profit_during_current_trade = 0 # Reset for new trade
            max_loss_during_current_trade = 0 # Reset for new trade

    if not trades:
        return {}

    # --- 績效計算 ---
    trades_df = pd.DataFrame(trades)
    win_trades = trades_df[trades_df['net_pnl'] > 0]
    loss_trades = trades_df[trades_df['net_pnl'] <= 0]
    
    total_net_pnl = trades_df['net_pnl'].sum()
    total_return_pct = (total_net_pnl / initial_capital) * 100
    win_rate = (len(win_trades) / len(trades_df) * 100) if not trades_df.empty else 0

    performance = {
        '總淨盈虧 ($)': total_net_pnl,
        '總報酬率 (%)': total_return_pct,
        '總交易次數': len(trades_df),
        '勝率 (%)': win_rate,
        '獲利交易數': len(win_trades),
        '虧損交易數': len(loss_trades),
        '平均每筆交易盈虧 ($)': trades_df['net_pnl'].mean(),
        '平均獲利 ($)': win_trades['net_pnl'].mean() if not win_trades.empty else 0,
        '平均虧損 ($)': loss_trades['net_pnl'].mean() if not loss_trades.empty else 0,
    }
    return performance, trades_df

def analyze_trade_distributions(trades_df):
    """分析最高獲利及最大虧損分佈及中位數"""
    if trades_df.empty:
        logging.info("無交易數據可供分析。")
        return

    buy_trades = trades_df[trades_df['position_type'] == 'BUY']
    sell_trades = trades_df[trades_df['position_type'] == 'SELL']

    logging.info("--- 交易分佈分析報告 ---")

    # 買入交易分析
    if not buy_trades.empty:
        logging.info("--- 買入交易 (BUY Trades) ---")
        buy_max_profits = buy_trades['max_profit_during_trade']
        logging.info(f"最高獲利中位數: {buy_max_profits.median():.2f}")
        logging.info(f"最高獲利分佈:\n{buy_max_profits.describe().to_string()}")

        buy_max_losses = buy_trades['max_loss_during_trade']
        logging.info(f"最大虧損中位數: {buy_max_losses.median():.2f}")
        logging.info(f"最大虧損分佈:\n{buy_max_losses.describe().to_string()}")
    else:
        logging.info("無買入交易數據。 সন")

    # 賣出交易分析
    if not sell_trades.empty:
        logging.info("--- 賣出交易 (SELL Trades) ---")
        sell_max_profits = sell_trades['max_profit_during_trade']
        logging.info(f"最高獲利中位數: {sell_max_profits.median():.2f}")
        logging.info(f"最高獲利分佈:\n{sell_max_profits.describe().to_string()}")

        sell_max_losses = sell_trades['max_loss_during_trade']
        logging.info(f"最大虧損中位數: {sell_max_losses.median():.2f}")
        logging.info(f"最大虧損分佈:\n{sell_max_losses.describe().to_string()}")
    else:
        logging.info("無賣出交易數據。 সন")

def run_analysis():
    """執行分析"""
    engine = get_engine()
    if engine is None:
        logging.error("無法連接資料庫，分析中止。 সন")
        return

    cycles_to_analyze = ['60m']

    for cycle in cycles_to_analyze:
        logging.info("=" * 60)
        logging.info(f"開始執行 {cycle} 週期 MACD 動能策略回測 (無停損停利，含布林通道過濾)... 張")
        logging.info("=" * 60)

        try:
            # 1. 獲取數據並計算指標
            end_date = datetime.date.today()
            start_date = end_date - datetime.timedelta(days=365)
            df = fetch_data(symbol="CL0000", cycle=cycle, limit=10000, start_date=start_date.strftime('%Y-%m-%d'), end_date=end_date.strftime('%Y-%m-%d'))
            if df is None or df.empty:
                logging.warning(f"{cycle} 週期無資料，跳過。 張")
                continue
            
            df_with_indicators = calculate_indicators(df).dropna()

            # 2. 產生交易信號 (MACD 突破 0 軸才觸發)
            # 判斷 MACD 是否突破 0 軸
            macd_cross_above_zero = (df_with_indicators['MACD'].shift(1) <= 0) & (df_with_indicators['MACD'] > 0)
            macd_cross_below_zero = (df_with_indicators['MACD'].shift(1) >= 0) & (df_with_indicators['MACD'] < 0)

            # 原始 MACD 買入/賣出信號
            macd_buy_signal = (df_with_indicators['MACD'] > df_with_indicators['MACD_Signal'])
            macd_sell_signal = (df_with_indicators['MACD'] < df_with_indicators['MACD_Signal'])

            # 結合 0 軸突破條件
            buy_condition = macd_buy_signal & macd_cross_above_zero
            sell_condition = macd_sell_signal & macd_cross_below_zero

            df_with_indicators['Signal'] = np.where(buy_condition, 'BUY', np.where(sell_condition, 'SELL', None))
            df_with_indicators = df_with_indicators.dropna(subset=['Signal'])

            # 3. 執行回測
            fixed_sl_percent = 0.004 # 0.4% 停損
            performance_report, trades_df = run_signal_reversal_backtest(df_with_indicators, fixed_sl_percent=fixed_sl_percent)

            # 4. 記錄績效
            logging.info(f"--- {cycle} 週期回測績效報告 ---")
            if not performance_report:
                logging.info("無足夠交易可計算績效。 張")
            else:
                for key, value in performance_report.items():
                    if isinstance(value, (float, np.floating)):
                        logging.info(f"{key:<25}: {value:.2f}")
                    else:
                        logging.info(f"{key:<25}: {value}")
            logging.info("\n")

            # 5. 分析交易分佈 (最高獲利及最大虧損)
            analyze_trade_distributions(trades_df)

        except Exception as e:
            logging.error(f"處理 {cycle} 週期時發生錯誤: {e}", exc_info=True)

if __name__ == "__main__":
    setup_logging()
    run_analysis()
