# simple_momentum_backtest.py
"""
對單一週期的雙通道策略進行回測 (布林通道 + 凱勒通道複合策略)。
策略：根據布林通道和凱勒通道的複合信號進行交易。
"""

import pandas as pd
import numpy as np
import logging
import warnings
import sys
import os
import datetime

# 將專案根目錄加到 sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 匯入專案的工具函式
from db_utils import fetch_data
from common.indicators import calculate_indicators
from config import get_engine, SYMBOLS_CONFIG
from backtests.backtest_utils import setup_logging, calculate_performance, log_performance_report

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

def run_signal_reversal_backtest(df, initial_capital=100000, fixed_sl_percent=None, take_profit_percent=None, stop_loss_percent=None, COMMISSION_PER_TRADE=10.0, CONTRACT_SIZE=1000):
    """根據訊號 DataFrame 執行訊號反轉的回測，並加入停損停利"""
    logging.info(f"進入回測函數，DataFrame 大小: {len(df)}")
    trades = []
    position = None
    entry_price = 0
    entry_time = None
    entry_volume = 0
    max_profit_during_current_trade = 0
    max_loss_during_current_trade = 0

    for timestamp, row in df.iterrows():
        signal = row['Signal']
        current_price = row['Close']
        exit_reason = None

        logging.debug(f"  時間: {timestamp}, 信號: {signal}, 當前倉位: {position}, 當前價格: {current_price}")

        # 如果有開倉，檢查出場條件
        if position is not None:
            # 計算當前浮動盈虧並更新最高獲利和最大虧損
            current_floating_pnl = 0
            if position == 'BUY':
                current_floating_pnl = (current_price - entry_price) * CONTRACT_SIZE
            elif position == 'SELL':
                current_floating_pnl = (entry_price - current_price) * CONTRACT_SIZE
            max_profit_during_current_trade = max(max_profit_during_current_trade, current_floating_pnl)
            max_loss_during_current_trade = min(max_loss_during_current_trade, current_floating_pnl)

            logging.debug(f"  浮動盈虧: {current_floating_pnl:.2f}, 最大獲利: {max_profit_during_current_trade:.2f}, 最大虧損: {max_loss_during_current_trade:.2f}")

            # 檢查停利條件
            if take_profit_percent and current_floating_pnl >= (entry_price * CONTRACT_SIZE * take_profit_percent):
                exit_reason = 'Take Profit'
            # 檢查停損條件
            elif stop_loss_percent and current_floating_pnl <= -(entry_price * CONTRACT_SIZE * stop_loss_percent):
                exit_reason = 'Stop Loss'
            # 檢查信號反轉
            elif signal != position:
                exit_reason = 'Signal Reversal'

            if exit_reason:
                logging.debug(f"  出場原因: {exit_reason}")
                exit_price = current_price

                if position == 'BUY':
                    pnl = (exit_price - entry_price) * CONTRACT_SIZE
                else:  # SELL
                    pnl = (entry_price - exit_price) * CONTRACT_SIZE

                net_pnl = pnl - (COMMISSION_PER_TRADE * 2)

                trades.append({
                    'entry_time': entry_time,
                    'exit_time': timestamp,
                    'position_type': position,
                    'entry_price': entry_price,
                    'exit_price': exit_price,
                    'pnl': pnl,
                    'net_pnl': net_pnl,
                    'max_profit_during_trade': max_profit_during_current_trade,
                    'max_loss_during_trade': max_loss_during_current_trade,
                    'exit_reason': exit_reason,
                    'entry_volume': entry_volume
                })
                position = None  # 平倉
                logging.debug(f"  交易記錄: {trades[-1]}")

        # 如果沒有開倉 (或剛平倉) 且有信號，則開立新倉
        if position is None and signal is not None:
            position = signal
            entry_price = current_price
            entry_time = timestamp
            entry_volume = row['Volume']
            max_profit_during_current_trade = 0
            max_loss_during_current_trade = 0
            logging.debug(f"  開立新倉: {position} @ {entry_price}")

    if not trades:
        logging.info("無足夠交易可計算績效。")
        return {}, pd.DataFrame()

    # --- 績效計算 ---
    trades_df = pd.DataFrame(trades)
    
    # 添加開倉小時欄位
    trades_df['entry_hour'] = trades_df['entry_time'].dt.hour

    # 計算累積盈虧和最大回落
    trades_df['cumulative_pnl'] = trades_df['net_pnl'].cumsum()
    trades_df['peak_pnl'] = trades_df['cumulative_pnl'].expanding().max()
    trades_df['drawdown'] = trades_df['peak_pnl'] - trades_df['cumulative_pnl']
    max_drawdown = trades_df['drawdown'].max()

    win_trades = trades_df[trades_df['net_pnl'] > 0]
    loss_trades = trades_df[trades_df['net_pnl'] <= 0]
    
    total_net_pnl = trades_df['net_pnl'].sum()
    total_return_pct = (total_net_pnl / initial_capital) * 100
    win_rate = (len(win_trades) / len(trades_df) * 100) if not trades_df.empty else 0

    performance = {
        '總淨盈虧 ($)': total_net_pnl,
        '總報酬率 (%)': total_return_pct,
        '總交易次數': len(trades_df),
        '勝率 (%)': win_rate,
        '獲利交易數': len(win_trades),
        '虧損交易數': len(loss_trades),
        '平均每筆交易盈虧 ($)': trades_df['net_pnl'].mean(),
        '平均獲利 ($)': win_trades['net_pnl'].mean() if not win_trades.empty else 0,
        '平均虧損 ($)': loss_trades['net_pnl'].mean() if not loss_trades.empty else 0,
        '最大回落 ($)': max_drawdown
    }
    return performance, trades_df

def analyze_trade_distributions(trades_df):
    """分析交易分佈及中位數"""
    if trades_df.empty:
        logging.info("無交易數據可供分析。")
        return

    buy_trades = trades_df[trades_df['position_type'] == 'BUY']
    sell_trades = trades_df[trades_df['position_type'] == 'SELL']

    logging.info("--- 交易分佈分析報告 ---")

    # 買入交易分析
    if not buy_trades.empty:
        logging.info("--- 買入交易 (BUY Trades) ---")
        logging.info(f"買入交易總數: {len(buy_trades)}")
        logging.info(f"買入交易平均淨盈虧: {buy_trades['net_pnl'].mean():.2f}")
    else:
        logging.info("無買入交易數據。")

    # 賣出交易分析
    if not sell_trades.empty:
        logging.info("--- 賣出交易 (SELL Trades) ---")
        logging.info(f"賣出交易總數: {len(sell_trades)}")
        logging.info(f"賣出交易平均淨盈虧: {sell_trades['net_pnl'].mean():.2f}")
    else:
        logging.info("無賣出交易數據。")

def run_analysis():
    """執行分析"""
    engine = get_engine()
    if engine is None:
        logging.error("無法連接資料庫，分析中止。")
        return

    symbol_to_analyze = 'CL0000' # 鎖定 CL0000
    cycle = '30m' # 固定為 30m 週期
    stop_loss_percent = 0.01 # 固定停損為 1.0%
    take_profit_percent = 0.015 # 固定停利為 1.5%
    label = f"最終策略 (SL={stop_loss_percent*100:.1f}%, TP={take_profit_percent*100:.1f}%)"

    logging.info("=" * 70)
    logging.info(f"開始執行 {symbol_to_analyze} 在 {cycle} 週期的回測 - {label}")
    logging.info("=" * 70)

    try:
        # 1. 獲取數據並計算指標
        end_date = datetime.date.today()
        start_date = end_date - datetime.timedelta(days=365)
        df = fetch_data(symbol=symbol_to_analyze, cycle=cycle, limit=10000, start_date=start_date.strftime('%Y-%m-%d'), end_date=end_date.strftime('%Y-%m-%d'))
        if df is None or df.empty:
            logging.warning(f"{symbol_to_analyze} 在 {cycle} 週期無資料，跳過。")
            return
        
        df_with_indicators = calculate_indicators(df).dropna()
        logging.info(f"計算指標後 DataFrame 大小: {len(df_with_indicators)}")

        # 2. 產生交易信號 (擠壓突破策略)
        squeeze_on = (df_with_indicators['BB_Upper'] < df_with_indicators['KC_Upper']) & (df_with_indicators['BB_Lower'] > df_with_indicators['KC_Lower'])

        buy_condition = squeeze_on.shift(1) & (df_with_indicators['Close'] > df_with_indicators['KC_Upper'])
        sell_condition = squeeze_on.shift(1) & (df_with_indicators['Close'] < df_with_indicators['KC_Lower'])

        df_with_indicators['Signal'] = np.where(buy_condition, 'BUY', np.where(sell_condition, 'SELL', None))
        logging.info(f"生成信號後 BUY 信號數量: {len(df_with_indicators[df_with_indicators['Signal'] == 'BUY'])}")
        logging.info(f"生成信號後 SELL 信號數量: {len(df_with_indicators[df_with_indicators['Signal'] == 'SELL'])}")
        df_with_indicators = df_with_indicators.dropna(subset=['Signal'])
        logging.info(f"移除無信號行後 DataFrame 大小: {len(df_with_indicators)}")

        # 3. 執行回測
        symbol_config = SYMBOLS_CONFIG[symbol_to_analyze]
        performance_report, trades_df = run_signal_reversal_backtest(
            df_with_indicators, 
            stop_loss_percent=stop_loss_percent,
            take_profit_percent=take_profit_percent,
            COMMISSION_PER_TRADE=symbol_config['COMMISSION_PER_TRADE'],
            CONTRACT_SIZE=symbol_config['CONTRACT_SIZE']
        )

        # 4. 記錄績效
        log_performance_report(performance_report, f"{symbol_to_analyze} {cycle} 週期回測績效報告")

        # 5. 分析交易分佈
        analyze_trade_distributions(trades_df)

        # 6. 按小時分析交易績效
        if not trades_df.empty:
            trades_df['entry_hour'] = trades_df['entry_time'].dt.hour
            hourly_performance = trades_df.groupby('entry_hour').agg(
                total_net_pnl=('net_pnl', 'sum'),
                total_trades=('net_pnl', 'count'),
                win_trades=('net_pnl', lambda x: (x > 0).sum()),
                loss_trades=('net_pnl', lambda x: (x <= 0).sum())
            )
            hourly_performance['win_rate'] = (hourly_performance['win_trades'] / hourly_performance['total_trades']) * 100

            logging.info("\n--- 按小時交易績效報告 ---")
            for hour, data in hourly_performance.iterrows():
                logging.info(f"小時: {hour:02d} - 總淨盈虧: {data['total_net_pnl']:.2f}, 總交易: {int(data['total_trades'])}, 勝率: {data['win_rate']:.2f}%")
        else:
            logging.info("無交易數據可供按小時分析。")

        # 7. 分析開倉時交易量與交易績效關係
        analyze_volume_performance(trades_df)

    except Exception as e:
        logging.error(f"處理 {symbol_to_analyze} 在 {cycle} 週期時發生錯誤: {e}", exc_info=True)

def analyze_volume_performance(trades_df):
    """分析開倉時交易量與交易績效的關係"""
    if trades_df.empty:
        logging.info("無交易數據可供分析交易量與績效的關係。")
        return

    # 將交易量分箱
    trades_df['volume_bin'] = pd.qcut(trades_df['entry_volume'], q=5, labels=False, duplicates='drop')

    volume_performance = trades_df.groupby('volume_bin').agg(
        total_net_pnl=('net_pnl', 'sum'),
        total_trades=('net_pnl', 'count'),
        win_trades=('net_pnl', lambda x: (x > 0).sum()),
        loss_trades=('net_pnl', lambda x: (x <= 0).sum())
    )
    volume_performance['win_rate'] = (volume_performance['win_trades'] / volume_performance['total_trades']) * 100

    logging.info("\n--- 按開倉交易量分箱的績效報告 ---")
    for bin_label, data in volume_performance.iterrows():
        min_vol = trades_df[trades_df['volume_bin'] == bin_label]['entry_volume'].min()
        max_vol = trades_df[trades_df['volume_bin'] == bin_label]['entry_volume'].max()
        logging.info(f"交易量範圍: {min_vol}-{max_vol} - 總淨盈虧: {data['total_net_pnl']:.2f}, 總交易: {int(data['total_trades'])}, 勝率: {data['win_rate']:.2f}%")

if __name__ == "__main__":
    setup_logging("squeeze_breakout_cl0000_final_strategy.log")
    run_analysis()
