# filtered_momentum_backtest.py
"""
回測一個帶有長期趨勢過濾的30分鐘MACD動能策略。
- 長期趨勢：2h EMA(50) vs EMA(200)
- 進出場信號：30m MACD vs Signal
- 只有當兩個週期方向一致時才持倉。
"""

import pandas as pd
import numpy as np
import logging
import warnings
import sys
import os

# 將專案根目錄加到 sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 匯入專案的工具函式
from db_utils import fetch_data
from common.indicators import calculate_indicators
from config import get_engine, COMMISSION_PER_TRADE, CONTRACT_SIZE

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

def setup_logging():
    """設定日誌記錄器"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler("filtered_momentum.log", mode='w', encoding='utf-8'),
            logging.StreamHandler()
        ]
    )

def run_filtered_backtest(df, initial_capital=100000):
    """根據訊號 DataFrame 執行帶有過濾條件的回測"""
    trades = []
    position = None
    entry_price = 0
    entry_time = None

    for timestamp, row in df.iterrows():
        signal = row['Final_Signal']
        
        # 平倉條件：當前的倉位與信號不符時（信號變為NEUTRAL或反向）
        if position is not None and position != signal:
            exit_price = row['Close_30m']
            
            if position == 'BUY':
                pnl = (exit_price - entry_price) * CONTRACT_SIZE
            else: # SELL
                pnl = (entry_price - exit_price) * CONTRACT_SIZE
            
            net_pnl = pnl - (COMMISSION_PER_TRADE * 2)

            trades.append({
                'entry_time': entry_time,
                'exit_time': timestamp,
                'position_type': position,
                'entry_price': entry_price,
                'exit_price': exit_price,
                'pnl': pnl,
                'net_pnl': net_pnl,
                'exit_reason': 'Signal Changed'
            })
            position = None # 平倉

        # 開倉條件：當前沒有倉位，且信號為 BUY 或 SELL
        if position is None and signal in ['BUY', 'SELL']:
            position = signal
            entry_price = row['Close_30m']
            entry_time = timestamp

    if not trades:
        return {}

    # --- 績效計算 ---
    trades_df = pd.DataFrame(trades)
    win_trades = trades_df[trades_df['net_pnl'] > 0]
    loss_trades = trades_df[trades_df['net_pnl'] <= 0]
    
    total_net_pnl = trades_df['net_pnl'].sum()
    total_return_pct = (total_net_pnl / initial_capital) * 100
    win_rate = (len(win_trades) / len(trades_df) * 100) if not trades_df.empty else 0

    performance = {
        '總淨盈虧 ($)': total_net_pnl,
        '總報酬率 (%)': total_return_pct,
        '總交易次數': len(trades_df),
        '勝率 (%)': win_rate,
        '獲利交易數': len(win_trades),
        '虧損交易數': len(loss_trades),
        '平均每筆交易盈虧 ($)': trades_df['net_pnl'].mean(),
        '平均獲利 ($)': win_trades['net_pnl'].mean() if not win_trades.empty else 0,
        '平均虧損 ($)': loss_trades['net_pnl'].mean() if not loss_trades.empty else 0,
    }
    return performance

def run_analysis():
    """執行分析"""
    engine = get_engine()
    if engine is None:
        logging.error("無法連接資料庫，分析中止。\n")
        return

    logging.info("=" * 60)
    logging.info(f"開始執行 30m MACD + 2h EMA 趨勢過濾策略回測...")
    logging.info("=" * 60)

    try:
        # 1. 獲取數據並計算指標
        cycles = ['30m', '2h']
        data_frames = {}
        for cycle in cycles:
            df = fetch_data(symbol="CL0000", cycle=cycle, limit=10000, start_date='2024-11-09', end_date='2025-11-09')
            if df is None or df.empty:
                logging.warning(f"{cycle} 週期無資料，跳過。\n")
                return
            df_indicators = calculate_indicators(df).add_suffix(f'_{cycle}')
            data_frames[cycle] = df_indicators

        # 2. 合併數據框
        merged_df = pd.merge(data_frames['30m'], data_frames['2h'], left_index=True, right_index=True, how='left')
        merged_df.fillna(method='ffill', inplace=True)
        merged_df.dropna(inplace=True)

        # 3. 產生交易信號
        # 長期趨勢信號
        merged_df['Trend_2h'] = np.where(merged_df['EMA_50_2h'] > merged_df['EMA_200_2h'], 'BUY', 'SELL')
        # 短期動能信號
        merged_df['Signal_30m'] = np.where(merged_df['MACD_30m'] > merged_df['MACD_Signal_30m'], 'BUY', 'SELL')
        
        # 最終信號：兩者同向才持倉，否則空倉
        merged_df['Final_Signal'] = np.where(merged_df['Trend_2h'] == merged_df['Signal_30m'], merged_df['Trend_2h'], 'NEUTRAL')

        # 4. 執行回測
        performance_report = run_filtered_backtest(merged_df)

        # 5. 記錄績效
        logging.info(f"--- 30m MACD + 2h EMA 趨勢過濾策略績效 ---")
        if not performance_report:
            logging.info("無足夠交易可計算績效。\n")
        else:
            for key, value in performance_report.items():
                if isinstance(value, (float, np.floating)):
                    logging.info(f"{key:<25}: {value:.2f}")
                else:
                    logging.info(f"{key:<25}: {value}")
        logging.info("\n")

    except Exception as e:
        logging.error(f"回測過程中發生錯誤: {e}", exc_info=True)

if __name__ == "__main__":
    setup_logging()
    run_analysis()
