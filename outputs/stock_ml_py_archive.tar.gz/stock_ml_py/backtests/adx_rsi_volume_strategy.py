import pandas as pd
import numpy as np
import logging
import warnings
import sys
import os
import datetime

# 將專案根目錄加到 sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# 匯入專案的工具函式
from db_utils import fetch_data
from common.indicators import calculate_indicators
from config import get_engine, SYMBOLS_CONFIG
from backtests.backtest_utils import setup_logging, calculate_performance, log_performance_report, run_signal_reversal_backtest

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

def run_analysis():
    """執行分析"""
    engine = get_engine()
    if engine is None:
        logging.error("無法連接資料庫，分析中止。")
        return

    symbol_to_analyze = 'CL0000' # 鎖定 CL0000
    cycle = '15m' # 固定為 15m 週期
    stop_loss_percent = 0.01 # 固定停損為 1.0%
    take_profit_percent = 0.015 # 固定停利為 1.5%
    initial_capital = 100000
    
    label = f"ADX-RSI-成交量趨勢追蹤策略 (SL={stop_loss_percent*100:.1f}%, TP={take_profit_percent*100:.1f}%)"

    logging.info("=" * 70)
    logging.info(f"開始執行 {symbol_to_analyze} 在 {cycle} 週期的回測 - {label}")
    logging.info("=" * 70)

    try:
        # 1. 獲取數據並計算指標
        end_date = datetime.date.today()
        start_date = end_date - datetime.timedelta(days=365)
        df = fetch_data(symbol=symbol_to_analyze, cycle=cycle, limit=10000, start_date=start_date.strftime('%Y-%m-%d'), end_date=end_date.strftime('%Y-%m-%d'))
        if df is None or df.empty:
            logging.warning(f"{symbol_to_analyze} 在 {cycle} 週期無資料，跳過。")
            return
        
        df_with_indicators = calculate_indicators(df).dropna()
        logging.info(f"計算指標後 DataFrame 大小: {len(df_with_indicators)}")

        # 2. 產生交易信號 (ADX-RSI-Volume Trend Following Strategy)
        # Entry Conditions (Long)
        long_condition_adx = (df_with_indicators['ADX'] > 30) & (df_with_indicators['PDI'] > df_with_indicators['MDI'])
        long_condition_ema = (df_with_indicators['Close'] > df_with_indicators['EMA_50'])
        long_condition_rsi = (df_with_indicators['RSI'] > 60) # RSI > 60 for stronger bullish momentum
        long_condition_volume = (df_with_indicators['Volume_VMA_Ratio'] > 1)

        buy_signal = long_condition_adx & long_condition_ema & long_condition_rsi & long_condition_volume

        # Entry Conditions (Short)
        short_condition_adx = (df_with_indicators['ADX'] > 30) & (df_with_indicators['MDI'] > df_with_indicators['PDI'])
        short_condition_ema = (df_with_indicators['Close'] < df_with_indicators['EMA_50'])
        short_condition_rsi = (df_with_indicators['RSI'] < 40) # RSI < 40 for stronger bearish momentum
        short_condition_volume = (df_with_indicators['Volume_VMA_Ratio'] > 1)

        sell_signal = short_condition_adx & short_condition_ema & short_condition_rsi & short_condition_volume

        df_with_indicators['Signal'] = np.where(buy_signal, 'BUY', np.where(sell_signal, 'SELL', None))
        
        logging.info(f"生成信號後 BUY 信號數量: {len(df_with_indicators[df_with_indicators['Signal'] == 'BUY'])}")
        logging.info(f"生成信號後 SELL 信號數量: {len(df_with_indicators[df_with_indicators['Signal'] == 'SELL'])}")
        df_with_indicators = df_with_indicators.dropna(subset=['Signal'])
        logging.info(f"移除無信號行後 DataFrame 大小: {len(df_with_indicators)}")

        # 3. 執行回測
        symbol_config = SYMBOLS_CONFIG[symbol_to_analyze]
        trades_df = run_signal_reversal_backtest(
            df_with_indicators, 
            stop_loss_percent=stop_loss_percent,
            take_profit_percent=take_profit_percent,
            # No trailing stop for now, can be added later if needed
            COMMISSION_PER_TRADE=symbol_config['COMMISSION_PER_TRADE'],
            CONTRACT_SIZE=symbol_config['CONTRACT_SIZE']
        )

        # 4. 計算並記錄績效
        performance_report = calculate_performance(trades_df, initial_capital)
        log_performance_report(performance_report, f"{symbol_to_analyze} {cycle} 週期回測績效報告")

    except Exception as e:
        logging.error(f"處理 {symbol_to_analyze} 在 {cycle} 週期時發生錯誤: {e}", exc_info=True)

if __name__ == "__main__":
    setup_logging("adx_rsi_volume_strategy.log")
    run_analysis()
