# multi_cycle_analysis.py
"""
多週期訊號同步分析腳本
"""

import pandas as pd
import numpy as np
import logging
import warnings

# 匯入專案的工具函式
from db_utils import fetch_data
from common.indicators import calculate_indicators
from config import get_engine, COMMISSION_PER_TRADE, CONTRACT_SIZE, STOP_LOSS_PCT

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

def setup_logging():
    """設定日誌記錄器"""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler("log/multi_cycle_analysis.log", mode='w', encoding='utf-8'),
            logging.StreamHandler()
        ]
    )

def run_backtest_with_trailing_stop(df, initial_capital=100000):
    """根據訊號 DataFrame 執行帶有移動停利的回測"""
    logging.info("--- 開始執行帶有移動停利的策略回測 ---")
    trades = []
    position = None
    entry_price = 0
    entry_time = None
    peak_price = 0  # 用於多單的移動停利
    trough_price = float('inf') # 用於空單的移動停利

    # 我們需要 Close, High, Low 來計算停利
    df_backtest = df[['Close_5m', 'High_5m', 'Low_5m', 'Signal']].copy()

    for timestamp, row in df_backtest.iterrows():
        signal = row['Signal']
        exit_reason = None

        # --- 檢查出場條件 ---
        if position is not None:
            # 1. 檢查移動停利
            if position == 'BUY':
                peak_price = max(peak_price, row['High_5m'])
                trailing_stop_price = peak_price * (1 - STOP_LOSS_PCT / 100)
                if row['Low_5m'] <= trailing_stop_price:
                    exit_price = trailing_stop_price
                    exit_reason = f"Trailing Stop at {exit_price:.2f}"
            
            elif position == 'SELL':
                trough_price = min(trough_price, row['Low_5m'])
                trailing_stop_price = trough_price * (1 + STOP_LOSS_PCT / 100)
                if row['High_5m'] >= trailing_stop_price:
                    exit_price = trailing_stop_price
                    exit_reason = f"Trailing Stop at {exit_price:.2f}"

            # 2. 檢查訊號反轉
            if not exit_reason and ((signal == 'SELL' and position == 'BUY') or (signal == 'BUY' and position == 'SELL')):
                exit_price = row['Close_5m']
                exit_reason = "Signal Reversal"

            # 3. 執行平倉
            if exit_reason:
                if position == 'BUY':
                    pnl = (exit_price - entry_price) * CONTRACT_SIZE
                else: # SELL
                    pnl = (entry_price - exit_price) * CONTRACT_SIZE
                
                net_pnl = pnl - (COMMISSION_PER_TRADE * 2)

                trades.append({
                    'entry_time': entry_time,
                    'exit_time': timestamp,
                    'position_type': position,
                    'entry_price': entry_price,
                    'exit_price': exit_price,
                    'pnl': pnl,
                    'net_pnl': net_pnl,
                    'exit_reason': exit_reason
                })
                position = None # 平倉後清空部位

        # --- 檢查進場條件 ---
        if position is None and signal in ['BUY', 'SELL']:
            position = signal
            entry_price = row['Close_5m']
            entry_time = timestamp
            if position == 'BUY':
                peak_price = entry_price
            else: # SELL
                trough_price = entry_price

    if not trades:
        return {}, pd.DataFrame()

    # --- 績效計算 ---
    trades_df = pd.DataFrame(trades)
    win_trades = trades_df[trades_df['net_pnl'] > 0]
    loss_trades = trades_df[trades_df['net_pnl'] <= 0]
    
    total_net_pnl = trades_df['net_pnl'].sum()
    total_return_pct = (total_net_pnl / initial_capital) * 100
    win_rate = (len(win_trades) / len(trades_df) * 100) if not trades_df.empty else 0

    performance = {
        '總淨盈虧 ($)': total_net_pnl,
        '總報酬率 (%)': total_return_pct,
        '總交易次數': len(trades_df),
        '勝率 (%)': win_rate,
        '獲利交易數': len(win_trades),
        '虧損交易數': len(loss_trades),
        '平均每筆交易盈虧 ($)': trades_df['net_pnl'].mean(),
        '平均獲利 ($)': win_trades['net_pnl'].mean() if not win_trades.empty else 0,
        '平均虧損 ($)': loss_trades['net_pnl'].mean() if not loss_trades.empty else 0,
    }
    return performance, trades_df

def run_multi_cycle_analysis():
    """執行多週期分析"""
    # 檢查資料庫連線
    engine = get_engine()
    if engine is None:
        logging.error("無法連接資料庫，分析中止。 সন")
        return

    cycles = ['5m', '30m', '2h']
    data_frames = {}

    # 1. 分別抓取和計算各週期的指標
    for cycle in cycles:
        logging.info(f"--- 正在處理 {cycle} 週期資料 ---")
        try:
            df = fetch_data(period="30d", cycle=cycle, limit=10000)
            if df is None or df.empty:
                logging.warning(f"{cycle} 週期無資料，跳過。 সন")
                continue
            
            df_indicators = calculate_indicators(df)
            # 為欄位名稱加上週期後綴 (e.g., Close_5m)
            df_indicators = df_indicators.add_suffix(f"_{cycle}")
            data_frames[cycle] = df_indicators
            logging.info(f"{cycle} 週期資料處理完成。 সন")

        except Exception as e:
            logging.error(f"處理 {cycle} 週期時發生錯誤: {e}")
            continue
    
    if len(data_frames) < len(cycles):
        logging.error("必要的資料週期不完整，無法進行合併分析。 সন")
        return

    # 2. 合併資料框
    logging.info("--- 正在合併與對齊多週期資料 ---")
    base_df = data_frames['5m']
    merged_df = base_df
    for cycle in ['30m', '2h']:
        if cycle in data_frames:
            # 使用 merge 替代 concat，並確保索引對齊
            merged_df = pd.merge(merged_df, data_frames[cycle], left_index=True, right_index=True, how='left')

    merged_df.fillna(method='ffill', inplace=True)
    merged_df.dropna(inplace=True)

    if merged_df.empty:
        logging.error("資料合併與填充後為空，無法產生報表。 সন")
        return

    logging.info("資料合併完成。 সন")

    # 3. 篩選並呈現報表
    columns_to_show = ['High_5m', 'Low_5m'] 
    for cycle in cycles:
        columns_to_show.extend([
            f'Close_{cycle}',
            f'MACD_{cycle}',
            f'MACD_Signal_{cycle}',
            f'BB_Position_{cycle}'
        ])
    # 額外加入 EMA 欄位
    columns_to_show.extend(['EMA_50_2h', 'EMA_200_2h'])
    
    final_columns = [col for col in columns_to_show if col in merged_df.columns]
    final_report = merged_df[final_columns].copy()

    # 4. 分析買賣訊號 (EMA趨勢 + 順勢突破策略)
    logging.info("--- 正在分析潛在買賣點 (EMA趨勢 + 順勢突破策略) ---")
    
    # 長期趨勢 (2h EMA)
    is_trend_bullish = final_report['EMA_50_2h'] > final_report['EMA_200_2h']
    is_trend_bearish = final_report['EMA_50_2h'] < final_report['EMA_200_2h']

    # 短期突破入場條件 (5m)
    is_5m_breakout_up = final_report['BB_Position_5m'] > 1
    is_5m_breakdown = final_report['BB_Position_5m'] < 0

    # 組合條件
    buy_condition = is_trend_bullish & is_5m_breakout_up
    sell_condition = is_trend_bearish & is_5m_breakdown

    final_report['Signal'] = ''
    final_report.loc[buy_condition, 'Signal'] = 'BUY'
    final_report.loc[sell_condition, 'Signal'] = 'SELL'

    # 5. 執行回測並計算績效
    performance_report, trades_df = run_backtest_with_trailing_stop(final_report)

    # 6. 記錄報表
    signals_only_report = final_report[final_report['Signal'] != ''].copy()

    logging.info("\n\n--- 多週期同步分析詳細報表 (最新 500 筆) ---")
    report_string_full = final_report.tail(500).to_string()
    logging.info("\n" + report_string_full)

    logging.info("\n\n--- 潛在買賣點分析精簡報表 ---")
    if signals_only_report.empty:
        logging.info("在分析的 500 筆資料中，未發現符合策略的買賣點。 সন")
    else:
        report_string_signals = signals_only_report.to_string()
        logging.info("\n" + report_string_signals)
    
    logging.info("\n\n--- 策略回測績效報告 (含 2.0% 移動停利) ---")
    if not performance_report:
        logging.info("無足夠交易可計算績效。 সন")
    else:
        for key, value in performance_report.items():
            if isinstance(value, float):
                logging.info(f"{key:<25}: {value:.2f}")
            else:
                logging.info(f"{key:<25}: {value}")

    # 7. 分析虧損交易
    logging.info("\n\n--- 虧損交易分析報告 ---")
    if trades_df.empty or trades_df[trades_df['net_pnl'] <= 0].empty:
        logging.info("本次回測中沒有虧損交易。 সন")
    else:
        losing_trades_df = trades_df[trades_df['net_pnl'] <= 0]
        # 提取虧損交易的進場時間點，並在 final_report 中找到對應的指標狀態
        losing_entries_report = final_report.loc[losing_trades_df['entry_time']]
        logging.info("以下為所有虧損交易在進場時的市場指標狀態：")
        logging.info("\n" + losing_entries_report.to_string())

if __name__ == "__main__":
    setup_logging()
    run_multi_cycle_analysis()
