# main.py
"""
主程式入口
執行特徵工程與機器學習模型訓練
"""

import warnings
import logging

# 匯入專案模組
from feature_engineering import create_features_and_target, setup_logging
from ml_utils import train_model
from visualization import setup_fonts

if __name__ == "__main__":
    warnings.filterwarnings("ignore")
    setup_logging()
    setup_fonts()
    
    logging.info("=" * 60)
    logging.info("開始執行特徵工程與機器學習流程")
    logging.info("=" * 60)
    
    # 1. 執行特徵工程並取得數據集
    X, y, feature_names = create_features_and_target()
    
    if X is None or y is None:
        logging.error("數據準備失敗，無法進行模型訓練。中止流程。")
    else:
        logging.info(f"數據準備完成。特徵集維度: {X.shape}, 目標集維度: {y.shape}")
        logging.info(f"特徵列表: {feature_names}")
        
        # 2. 訓練機器學習模型
        try:
            logging.info("\n" + "=" * 60)
            logging.info("準備開始訓練模型...")
            logging.info("=" * 60)
            model, scaler, selector = train_model(X, y, feature_names)
            
            if model:
                logging.info("\n" + "=" * 60)
                logging.info("模型訓練流程成功結束！")
                logging.info("=" * 60)
            else:
                logging.warning("模型訓練未返回有效模型。")

        except Exception as e:
            logging.error("模型訓練過程中發生未預期的錯誤", exc_info=True)
