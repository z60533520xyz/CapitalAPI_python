import pandas as pd
import numpy as np
import logging
import warnings

# 匯入專案的工具函式
from common.db_utils import DatabaseManager
from common.indicators import calculate_indicators
from config import PRICE_CHANGE_THRESHOLD
from backtests.backtest_utils import setup_logging # Import from backtest_utils

warnings.filterwarnings("ignore", category=FutureWarning)
warnings.filterwarnings("ignore", category=UserWarning)

def create_features_and_target(symbol, cycle, period="250d", start_date=None, end_date=None):
    """執行特徵工程並創建目標標籤 (僅使用 2h 週期)"""
    # 檢查資料庫連線
    db_manager = DatabaseManager()
    if db_manager.get_engine() is None:
        logging.error("無法連接資料庫，分析中止。")
        return None, None, None

    # 1. 只抓取 2h 週期資料
    logging.info("--- 正在處理 2h 週期資料 ---")
    try:
        # Pass start_date and end_date to fetch_data
        df = db_manager.fetch_data_flex(symbol=symbol, period=period, cycle=cycle, limit=10000, start_date=start_date, end_date=end_date)
        if df is None or df.empty:
            logging.warning(f"{cycle} 週期無資料，中止。")
            return None, None, None
        
        df_indicators = calculate_indicators(df)
        merged_df = df_indicators.add_suffix(f'_{cycle}')
        logging.info(f"{cycle} 週期資料處理完成。")

    except Exception as e:
        logging.error(f"處理 {cycle} 週期時發生錯誤: {e}")
        return None, None, None

    # 2. 特徵工程 (Feature Engineering)
    logging.info(f"--- 開始進行特徵工程 (僅 {cycle}) ---")
    features_df = pd.DataFrame(index=merged_df.index)

    # 趨勢特徵
    features_df['trend_ema'] = np.where(merged_df[f'EMA_50_{cycle}'] > merged_df[f'EMA_200_{cycle}'], 1, -1)

    # 動能特徵
    features_df[f'macd_power'] = (merged_df[f'MACD_{cycle}'] - merged_df[f'MACD_Signal_{cycle}']) / merged_df[f'Close_{cycle}'] * 1000
    features_df[f'rsi'] = merged_df[f'RSI_{cycle}']

    # 波動率特徵
    features_df[f'bb_width'] = (merged_df[f'BB_Upper_{cycle}'] - merged_df[f'BB_Lower_{cycle}']) / merged_df[f'BB_Middle_{cycle}']

    # 價格位置特徵
    features_df['price_dist_ema200'] = (merged_df[f'Close_{cycle}'] - merged_df[f'EMA_200_{cycle}']) / merged_df[f'EMA_200_{cycle}'] * 100
    features_df[f'bb_position'] = merged_df[f'BB_Position_{cycle}']

    logging.info("特徵工程完成。")

    # 3. 產生目標 (Label) - 預測下一根 2h K棒的漲跌
    logging.info("--- 正在產生目標標籤 (Label) ---")
    future_price = merged_df[f'Close_{cycle}'].shift(-1)
    price_change_ratio = future_price / merged_df[f'Close_{cycle}']
    
    # 閾值設為 0，只判斷漲跌方向
    conditions = [
        (price_change_ratio > 1 + PRICE_CHANGE_THRESHOLD), # 上漲超過 PRICE_CHANGE_THRESHOLD
        (price_change_ratio < 1 - PRICE_CHANGE_THRESHOLD)  # 下跌超過 PRICE_CHANGE_THRESHOLD
    ]
    choices = [1, -1] # 1 for Long, -1 for Short
    target = np.select(conditions, choices, default=0) # 0 for Neutral
    
    features_df['Label'] = target

    # 4. 清理數據
    original_len = len(features_df)
    features_df.dropna(inplace=True)
    logging.info(f"從 {original_len} 筆資料中清理後剩餘 {len(features_df)} 筆有效資料")

    if features_df.empty:
        return None, None, None

    # 5. 準備最終的 X, y
    feature_names = [col for col in features_df.columns if col != 'Label']
    X = features_df[feature_names]
    y = features_df['Label']
    
    return X, y, feature_names

if __name__ == "__main__":
    setup_logging("feature_engineering.log") # Use setup_logging from backtest_utils
    # Example usage with specific dates
    symbol_to_analyze = 'CL0000'
    training_cycle = '2h'
    training_start_date = '2025-03-01'
    training_end_date = '2025-11-07'
    X, y, feature_names = create_features_and_target(symbol_to_analyze, training_cycle, start_date=training_start_date, end_date=training_end_date)
    if X is not None:
        logging.info("\n\n--- 特徵數據集 (X) 的前 5 筆 ---")
        logging.info("\n" + X.head().to_string())
        logging.info("\n\n--- 目標標籤 (y) 的分佈 ---")
        logging.info("\n" + str(y.value_counts()))
        logging.info(f"\n特徵數量: {len(feature_names)}")
        logging.info(f"數據集大小: {X.shape[0]} 筆")