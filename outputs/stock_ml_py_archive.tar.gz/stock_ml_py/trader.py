# trader.py
"""
主要交易類別
整合所有模組
"""
import logging
from common.db_utils import DatabaseManager
from common.indicators import calculate_indicators
from strategy import generate_signals as strategy_generate_signals, calculate_returns as strategy_calculate_returns
from visualization import print_latest_status, plot_analysis
from config import SYMBOL, EXCHANGE, SYMBOL_DISPLAY, PRICE_UNIT

class CommodityTrader:
    def __init__(self, symbol=SYMBOL, exchange=EXCHANGE, name=SYMBOL_DISPLAY):
        self.symbol = symbol
        self.display_symbol = name
        self.exchange = exchange
        self.data = None
        self.signals = None
        self.performance = None
        self.trades = None
        self.cycle = None
        self.model = None
        self.scaler = None
        self.selector = None
        self.db_manager = DatabaseManager()

    def fetch_data(self, period="6mo", cycle="60m", limit=1000):
        """從 MySQL 抓取資料"""
        self.data = self.db_manager.fetch_data_flex(symbol=self.symbol, period=period, cycle=cycle, limit=limit)
        return self.data

    def calculate_indicators(self):
        """計算技術指標"""
        self.data = calculate_indicators(self.data)
        return self.data

    def generate_signals(self, cycle="60m"):
        """生成雙向交易訊號"""
        self.cycle = cycle
        self.signals, self.model, self.scaler, self.selector = strategy_generate_signals(self.data, cycle=cycle)
        return self.signals

    def calculate_returns(self):
        """計算報酬"""
        self.signals, self.performance, self.trades = strategy_calculate_returns(self.signals, self.model, self.scaler)
        return self.signals

    def print_latest_status(self):
        """顯示最新狀態"""
        print_latest_status(self.signals, self.performance, self.cycle)

    def plot_analysis(self):
        """繪製圖表"""
        return plot_analysis(self.signals, self.performance, self.cycle)

    def run_backtest(self, cycle="60m", period="1mo", limit=1000):
        """執行回測 - 雙向交易版 (含交易成本)"""
        logging.info(f"Running {cycle} Bi-Directional Backtest...")
        logging.info(f"Parameters: {period}, Limit: {limit} bars")
        logging.info("-" * 45)
        logging.info(f"Starting {self.symbol} {cycle} Bi-Directional Backtest...")
        
        try:
            logging.info("\nStep 1: Fetch Data...")
            self.fetch_data(period=period, cycle=cycle, limit=limit)
            logging.info(f"Data: {len(self.data)} bars")
            
            logging.info("\nStep 2: Calculate Indicators...")
            self.calculate_indicators()
            logging.info(f"Indicators: {len(self.data)} bars")
            
            logging.info("\nStep 3: Generate Bi-Directional ML Signals...")
            self.generate_signals(cycle=cycle)
            logging.info(f"Signals: {len(self.signals)} bars")
            logging.info(f"Signal columns: {self.signals.columns.tolist()}")
            logging.info(f"Long signals: {len(self.signals[self.signals['Trade_Signal'] == 1])}")
            logging.info(f"Short signals: {len(self.signals[self.signals['Trade_Signal'] == -1])}")
            logging.info(self.signals[['Trade_Signal', 'Prob_Short', 'Prob_Neutral', 'Prob_Long']].tail(10))
            
            logging.info("\nStep 4: Calculate Bi-Directional Performance (with Costs)...")
            self.calculate_returns()
            logging.info(f"Performance: {len(self.signals)} bars")
            
            logging.info("\nBi-Directional Trading Performance Report (with Costs)")
            logging.info("-" * 50)
            for key, value in self.performance.items():
                # 將中文 key 替換為英文顯示
                eng_key = key.replace('總報酬率 (扣成本) (%)', 'Net Return (After Costs) (%)') \
                            .replace('毛報酬率 (未扣成本) (%)', 'Gross Return (Before Costs) (%)') \
                            .replace('成本影響 (%)', 'Cost Impact (%)') \
                            .replace('市場報酬率 (%)', 'Market Return (%)') \
                            .replace('超額報酬率 (%)', 'Excess Return (%)') \
                            .replace('多單報酬率 (%)', 'Long Return (%)') \
                            .replace('空單報酬率 (%)', 'Short Return (%)') \
                            .replace('夏普比率', 'Sharpe Ratio') \
                            .replace('總勝率 (%)', 'Overall Win Rate (%)') \
                            .replace('多單勝率 (%)', 'Long Win Rate (%)') \
                            .replace('空單勝率 (%)', 'Short Win Rate (%)') \
                            .replace('ML 預測準確率 (%)', 'ML Accuracy (%)') \
                            .replace('獲利交易', 'Profitable Trades') \
                            .replace('最大回撤 (%)', 'Max Drawdown (%)') \
                            .replace('總交易次數', 'Total Trades') \
                            .replace('總交易成本 ($)', 'Total Trading Cost ($)') \
                            .replace('每筆成本佔比 (%)', 'Cost per Trade (%)') \
                            .replace('平均每筆報酬率 (%)', 'Avg Trade Return (%)')
                logging.info(f"{eng_key:<25}: {value}")
            
            logging.info("\nLatest Market Status")
            self.print_latest_status()
            
            # ========== 交易明細報表 ==========
            if not self.trades.empty:
                logging.info(f"\nRecent 10 Trades Detail:")
                logging.info("-" * 90)
                
                num_display = min(10, len(self.trades))
                trades_to_show = self.trades.tail(num_display).copy()
                
                display_data = []
                for i, (idx, trade) in enumerate(trades_to_show.iterrows()):
                    trade_info = {
                        'Trade_No': num_display - i,
                        'Time_Index': i,
                        'Trade_Type': trade.get('Trade_Type', 'N/A'),
                        'Entry_Price': trade.get('Entry_Price', 0),
                        'Predict_Prob': trade.get('Predict_Prob', 0)
                    }
                    
                    if 'Trade_Return_Pct' in trade:
                        trade_info['Trade_Return'] = trade['Trade_Return_Pct']
                    elif 'Trade_Return' in trade:
                        trade_info['Trade_Return'] = trade['Trade_Return']
                    else:
                        trade_info['Trade_Return'] = 0
                    
                    display_data.append(trade_info)
                
                if display_data:
                    for trade_info in display_data:
                        direction = "LONG" if trade_info['Trade_Type'] == 'Long' else "SHORT" if trade_info['Trade_Type'] == 'Short' else "EXIT"
                        profit_color = "" if trade_info['Trade_Return'] > 0 else ""
                        
                        logging.info(f"Trade #{trade_info['Trade_No']:>2} | {direction:>8} | "
                            f"${trade_info['Entry_Price']:>6.2f} | "
                            f"{trade_info['Trade_Return']:>+7.2f}% | "
                            f"Prob: {trade_info['Predict_Prob']:>5.1%}")
                else:
                    logging.info("   No trade details available")
                
                logging.info("=" * 90)
            else:
                logging.info(f"\nNo trades executed in this period")
            
            logging.info("\nStep 5: Plot Analysis...")
            success = self.plot_analysis()
            
            # ========== 修正：使用正確的鍵名 ==========
            net_return = self.performance.get('總報酬率 (扣成本) (%)', 0)
            logging.info(f"\n{cycle} Bi-Directional Backtest Complete! Net Return: {net_return:.2f}%")
            return self.performance
            
        except Exception as e:
            logging.exception(f"{cycle} Failed:")
            return None