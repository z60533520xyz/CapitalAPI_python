import os
import subprocess
import sys
import re
import pandas as pd
import locale # Import locale

# 獲取系統預設編碼
SYSTEM_DEFAULT_ENCODING = locale.getpreferredencoding(False)

# 專案根目錄
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
BACKTESTS_DIR = os.path.join(PROJECT_ROOT, 'backtests')
LOGS_DIR = os.path.join(PROJECT_ROOT, 'logs')

def decode_str_for_display(s):
    """嘗試將字串從 UTF-8 解碼為系統預設編碼，以正確顯示中文字元"""
    try:
        return s.encode('utf-8').decode(SYSTEM_DEFAULT_ENCODING)
    except (UnicodeEncodeError, UnicodeDecodeError):
        return s # 如果解碼失敗，返回原始字串

def run_backtest_strategy(strategy_path):
    """執行單個回測策略腳本"""
    print(f"Running strategy: {os.path.basename(strategy_path)}")
    try:
        # 使用 subprocess 執行策略腳本
        result = subprocess.run(
            [sys.executable, strategy_path],
            capture_output=True,
            text=True,
            check=True,
            encoding='utf-8', # Explicitly set encoding to utf-8
            errors='replace' # Replace undecodable characters
        )
        print(f"  {os.path.basename(strategy_path)} finished successfully.")
        return True, result.stdout + result.stderr
    except subprocess.CalledProcessError as e:
        print(f"  Error running {os.path.basename(strategy_path)}: {e}")
        print(f"  Stdout: {e.stdout or ''}")
        print(f"  Stderr: {e.stderr or ''}")
        return False, (e.stdout or "") + (e.stderr or "")
    except Exception as e:
        print(f"  An unexpected error occurred while running {os.path.basename(strategy_path)}: {e}")
        # For general exceptions, stdout/stderr might not be attributes of e
        return False, str(e)

def parse_log_for_performance(log_file_path):
    """從日誌文件中解析績效報告"""
    performance_data = {
        'Strategy': os.path.basename(log_file_path).replace('.log', ''),
        'Total Net PnL': 0.0,
        'Max Drawdown': 0.0,
        'Win Rate': 0.0,
        'Total Trades': 0
    }
    try:
        with open(log_file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            print(f"\n--- Content of {log_file_path} ---")
            print(content)
            print(f"--- End of Content for {log_file_path} ---\n")
            
            # 提取策略名稱 (使用檔案名稱作為策略名稱，避免亂碼問題)
            performance_data['Strategy'] = os.path.basename(log_file_path).replace('.log', '')

            # 提取總淨盈虧
            pnl_match = re.search(r"總淨盈虧 \(\$\)\s*:\s*([-\d.]+)", content)
            if pnl_match:
                performance_data['Total Net PnL'] = float(pnl_match.group(1))
            
            # 提取最大虧損
            drawdown_match = re.search(r"最大回落 \(\$\)\s*:\s*([-\d.]+)", content)
            if drawdown_match:
                performance_data['Max Drawdown'] = float(drawdown_match.group(1))

            # 提取勝率
            win_rate_match = re.search(r"勝率 \(%\)\s*:\s*([\d.]+)", content)
            if win_rate_match:
                performance_data['Win Rate'] = float(win_rate_match.group(1))

            # 提取總交易次數
            total_trades_match = re.search(r"總交易次數\s*:\s*(\d+)", content)
            if total_trades_match:
                performance_data['Total Trades'] = int(total_trades_match.group(1))

    except FileNotFoundError:
        print(f"Log file not found: {log_file_path}")
        return performance_data
    except Exception as e:
        print(f"Error parsing log file {log_file_path}: {e}")
    return performance_data

def main():
    if not os.path.exists(LOGS_DIR):
        os.makedirs(LOGS_DIR)

    strategy_files = []
    for filename in os.listdir(BACKTESTS_DIR):
        if filename.endswith('.py') and filename != 'backtest_utils.py': # Include all .py files except backtest_utils.py
            strategy_files.append(os.path.join(BACKTESTS_DIR, filename))
    
    if not strategy_files:
        print("No backtest strategy files found in 'backtests/' directory.")
        return

    print(f"Found {len(strategy_files)} strategy files to run.")

    all_performance_data = []

    for strategy_file in strategy_files:
        success, output = run_backtest_strategy(strategy_file)
        if success:
            # 假設每個策略都會生成一個以其文件名命名的日誌文件在 logs/ 目錄中
            log_filename = os.path.basename(strategy_file).replace('.py', '.log')
            log_file_path = os.path.join(LOGS_DIR, log_filename)
            
            # 等待日誌文件寫入完成 (簡單延遲，實際應用可能需要更穩健的機制)
            import time
            time.sleep(5) 

            performance = parse_log_for_performance(log_file_path)
            if performance:
                all_performance_data.append(performance)
        else:
            print(f"Strategy {os.path.basename(strategy_file)} failed to run.")
            print(f"Output: {output}")

    if all_performance_data:
        performance_df = pd.DataFrame(all_performance_data)
        # Apply decoding for display
        performance_df['Strategy'] = performance_df['Strategy'].apply(decode_str_for_display)
        performance_df = performance_df.sort_values(by='Total Net PnL', ascending=False).reset_index(drop=True)
        
        print("\n--- All Strategies Performance Summary ---")
        print(performance_df.to_string())

        print("\n--- Top 3 Strategies by Total Net PnL ---")
        print(performance_df.head(3).to_string())
    else:
        print("\nNo performance data collected from any strategy.")

if __name__ == "__main__":
    # 確保 pandas 已經匯入
    try:
        import pandas as pd
    except ImportError:
        print("Pandas not found. Please install it using 'pip install pandas'")
        sys.exit(1)
    main()
