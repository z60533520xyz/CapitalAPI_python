# config.py
"""
專案配置檔案
包含資料庫設定、全域常量等
"""

import sqlalchemy
import logging
from datetime import datetime, timedelta

# ========== 全域設定 ==========
COMMISSION_PER_TRADE = 200.0
CONTRACT_SIZE = 200
DB_CONFIG = {
    'host': 'localhost',
    'database': 'stocks_ml',
    'user': 'stocks',              # 請填入你的 MySQL 使用者名稱
    'password': 'jbR3nKAMheB9aKE1',              # 請填入你的 MySQL 密碼
    'port': 3306
}

CYCLE_MAPPING = {
    '5m': 2, '15m': 3, '30m': 4, '60m': 5,
    '1d': 6, '1w': 7, '1M': 8, '2h': 9
}

# ================== 標的設定字典 ==================
SYMBOLS_CONFIG = {
    'CL0000': {
        'EXCHANGE': 'NYM',
        'SYMBOL_DISPLAY': '輕原油 (CL)',
        'PRICE_UNIT': 'USD/BBL',
        'CONTRACT_SIZE': 1000,
        'COMMISSION_PER_TRADE': 10.0,
        'CYCLES': {
            '5m': {
                'KC_PERIOD': 20,
                'KC_MULTIPLIER': 2.0
            },
            '30m': {
                'KC_PERIOD': 30,
                'KC_MULTIPLIER': 2.0
            },
            '60m': {
                'KC_PERIOD': 20,
                'KC_MULTIPLIER': 2.0
            }
        }
    },
    'NQ0000': {
        'EXCHANGE': 'CME',
        'SYMBOL_DISPLAY': '納斯達克100指數期貨 (NQ)',
        'PRICE_UNIT': 'points',
        'CONTRACT_SIZE': 20,
        'COMMISSION_PER_TRADE': 10.0,
        'CYCLES': {
            '5m': {
                'KC_PERIOD': 10,
                'KC_MULTIPLIER': 2.5
            },
            '30m': {
                'KC_PERIOD': 20,
                'KC_MULTIPLIER': 2.0
            },
            '60m': {
                'KC_PERIOD': 20,
                'KC_MULTIPLIER': 2.0
            }
        }
    },
    'YM0000': {
        'EXCHANGE': 'CBOT',
        'SYMBOL_DISPLAY': '小道瓊指數期貨 (YM)',
        'PRICE_UNIT': 'points',
        'CONTRACT_SIZE': 5,
        'COMMISSION_PER_TRADE': 10.0,
        'CYCLES': {
            '5m': {
                'KC_PERIOD': 20,
                'KC_MULTIPLIER': 2.0
            },
            '30m': {
                'KC_PERIOD': 20,
                'KC_MULTIPLIER': 2.0
            },
            '60m': {
                'KC_PERIOD': 20,
                'KC_MULTIPLIER': 2.0
            }
        }
    },
    'TX00': {
        'EXCHANGE': 'TAIFEX',
        'SYMBOL_DISPLAY': '台股指數期貨 (TX)',
        'PRICE_UNIT': 'TWD/point',
        'CONTRACT_SIZE': 200,
        'COMMISSION_PER_TRADE': 200.0,
        'CYCLES': {
            '5m': {
                'KC_PERIOD': 10,
                'KC_MULTIPLIER': 3.0
            },
            '30m': {
                'KC_PERIOD': 20,
                'KC_MULTIPLIER': 2.0
            }
        }
    },
    'ES0000': {
        'EXCHANGE': 'CME',
        'SYMBOL_DISPLAY': 'S&P 500 指數期貨 (ES)',
        'PRICE_UNIT': 'points',
        'CONTRACT_SIZE': 50,
        'COMMISSION_PER_TRADE': 10.0,
        'CYCLES': {
            '5m': {
                'KC_PERIOD': 20,
                'KC_MULTIPLIER': 2.0
            },
            '30m': {
                'KC_PERIOD': 20,
                'KC_MULTIPLIER': 2.0
            },
            '60m': {
                'KC_PERIOD': 20,
                'KC_MULTIPLIER': 2.0
            }
        }
    }
}

# =================================================

# ML 參數
ML_WINDOW = 5
FUTURE_WINDOW = 5
MLP_HIDDEN_LAYERS = (64, 32)
MLP_MAX_ITER = 500
MLP_RANDOM_STATE = 42

# 技術指標參數 (通用)
MACD_FAST = 12
MACD_SLOW = 26
MACD_SIGNAL = 9
BB_PERIOD = 20
MA_PERIODS = [5, 10, 20]

# 訊號閾值
LONG_THRESHOLD = 0.6
SHORT_THRESHOLD = 0.4
PRICE_CHANGE_THRESHOLD = 0.007

# 風險管理：止損百分比
STOP_LOSS_PCT = 2.0

# 要選擇的最佳特徵數量 (K)
ML_FEATURES_K = 90

# 資料庫引擎 (延遲初始化)
engine = None

def get_engine():
    """取得資料庫引擎"""
    global engine
    if engine is None:
        try:
            connection_string = (
                f"mysql+mysqlconnector://{DB_CONFIG['user']}:{DB_CONFIG['password']}"
                f"@{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}?charset=utf8mb4&collation=utf8mb4_general_ci"
            )
            engine = sqlalchemy.create_engine(connection_string)
            
            with engine.connect() as conn:
                result = conn.execute(sqlalchemy.text("SELECT 1 as test")).scalar()
                if result == 1:
                    logging.info("資料庫連線測試成功")
                else:
                    logging.warning(f"資料庫連線測試結果異常：{result}")
            
            logging.info("MySQL 連線成功")
                
        except Exception as e:
            logging.error(f"資料庫連線失敗：{e}", exc_info=True)
            engine = None
    return engine