# visualization.py
"""
視覺化模組
繪製圖表、顯示狀態
"""

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import pandas as pd
import logging
from config import SYMBOL_DISPLAY, PRICE_UNIT, CONTRACT_SIZE

def setup_fonts():
    """設定 Matplotlib 中文字體"""
    logging.info("載入中文字體支援...")
    plt.rcParams['font.sans-serif'] = ['Microsoft JhengHei', 'SimHei', 'DejaVu Sans']
    plt.rcParams['axes.unicode_minus'] = False
    logging.info("字體設定完成")

def print_latest_status(df, performance, cycle="60m"):
    """顯示最新市場狀態 - 雙向交易版 (三分類模型)"""
    if df.empty:
        logging.warning("無法顯示最新狀態：無訊號資料。")
        return

    latest = df.iloc[-1]
    current_price = latest['Close']
    macd = latest['MACD']
    macd_signal = latest['MACD_Signal']
    ma5 = latest['MA5']
    ma10 = latest['MA10']
    ma20 = latest['MA20']
    position = latest['Position']
    
    # Get new probabilities
    prob_long = latest.get('Prob_Long', 0)
    prob_short = latest.get('Prob_Short', 0)

    # 交易成本資訊
    total_trades = performance.get('總交易次數', 0)
    total_cost = performance.get('總交易成本 ($)', 0)
    avg_cost_pct = performance.get('每筆成本佔比 (%)', 0)
    
    # ML Sentiment based on new probabilities
    if prob_long > prob_short and prob_long > 0.5:
        ml_sentiment = f"{prob_long * 100:.1f}% Strong Bull"
    elif prob_short > prob_long and prob_short > 0.5:
        ml_sentiment = f"{prob_short * 100:.1f}% Strong Bear"
    else:
        ml_sentiment = f"Neutral (L:{prob_long:.1%}/S:{prob_short:.1%})"

    # 持倉狀態顯示
    if position == 1:
        status = "Long Position"
    elif position == -1:
        status = "Short Position"
    else:
        status = "No Position"

    # 交易建議 (using new probabilities)
    long_threshold_suggestion = 0.6 
    short_threshold_suggestion = 0.6

    if position == 1:  # 持有多單
        if prob_short > short_threshold_suggestion:
            suggestion = "Close Long, Open Short (Strong Bear Signal)"
        elif prob_long < 0.5:
            suggestion = "Consider Reducing (Weakening Signal)"
        else:
            suggestion = "Hold Long (Bullish Signal)"
            
    elif position == -1:  # 持有空單
        if prob_long > long_threshold_suggestion:
            suggestion = "Close Short, Open Long (Strong Bull Signal)"
        elif prob_short < 0.5:
            suggestion = "Consider Reducing (Weakening Signal)"
        else:
            suggestion = "Hold Short (Bearish Signal)"
            
    else:  # 不持有
        if prob_long > long_threshold_suggestion and macd > macd_signal:
            suggestion = "Open Long (Strong Bull + MACD Confirm)"
        elif prob_short > short_threshold_suggestion and macd < macd_signal:
            suggestion = "Open Short (Strong Bear + MACD Confirm)"
        else:
            suggestion = "Wait for Clear Signal"

    report_lines = [
        "\n" + "="*70,
        f"{SYMBOL_DISPLAY} Latest Status (Bi-Directional ML + Costs)",
        "="*70,
        f"Latest Price:    ${current_price:>8.2f} {PRICE_UNIT}",
        f"MA5:             ${ma5:>8.2f} {PRICE_UNIT}",
        f"MA10:            ${ma10:>8.2f} {PRICE_UNIT}",
        f"MA20:            ${ma20:>8.2f} {PRICE_UNIT}",
        f"MACD:            {macd:>7.2f} {'Bullish' if macd > macd_signal else 'Bearish'}",
        f"BB Position:     {latest['BB_Position']:>5.1%} {'High' if latest['BB_Position'] > 0.8 else 'Low' if latest['BB_Position'] < 0.2 else 'Mid'}",
        f"ML Signal:         {ml_sentiment}",
        f"Position:        {status}",
        "Trading Costs:",
        f"   Total Trades:    {total_trades} trades",
        f"   Total Cost:      ${total_cost:>8.2f}",
        f"   Cost per Trade:  {avg_cost_pct:>5.2f}% of price",
        f"\n{suggestion}",
        "="*70
    ]
    logging.info("\n".join(report_lines))

def plot_analysis(df, performance, cycle="60m"):
    """繪製分析圖表 - 雙向交易版：4面板 (修正日期顯示)"""
    if 'Cumulative_Market' not in df.columns:
        raise ValueError("需先計算報酬")

    if not isinstance(df.index, pd.DatetimeIndex):
        logging.warning("警告：索引不是 DatetimeIndex，無法繪製圖表。" )
        return False

    date_range = df.index.max() - df.index.min()
    logging.info(f"日期範圍：{df.index.min()} 到 {df.index.max()} ({date_range})")
    
    if date_range <= pd.Timedelta(hours=24):
        locator = mdates.HourLocator(interval=2)
        formatter = mdates.DateFormatter('%H:%M')
    elif date_range <= pd.Timedelta(days=7):
        locator = mdates.HourLocator(interval=6)
        formatter = mdates.DateFormatter('%m-%d %H:%M')
    elif date_range <= pd.Timedelta(days=31):
        locator = mdates.DayLocator(interval=3)
        formatter = mdates.DateFormatter('%m-%d')
    else:
        locator = mdates.WeekdayLocator(interval=1)
        formatter = mdates.DateFormatter('%Y-%m-%d')
    
    fig1, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12))
    fig1.suptitle(f'{SYMBOL_DISPLAY} Bi-Directional ML Trading Analysis ({cycle})', fontsize=18, fontweight='bold')
    
    # Panel 1: Price + MAs + Signals
    ax1.plot(df.index, df['Close'], label='Close', linewidth=2, color='navy')
    ax1.plot(df.index, df['MA5'], label='MA5', linewidth=1, color='orange', alpha=0.8)
    ax1.plot(df.index, df['MA10'], label='MA10', linewidth=1, color='green', alpha=0.8)
    ax1.plot(df.index, df['MA20'], label='MA20', linewidth=1, color='red', alpha=0.8)
    
    long_entries = df[df['Trade_Signal'] == 1]
    short_entries = df[df['Trade_Signal'] == -1]
    ax1.scatter(long_entries.index, long_entries['Close'], color='limegreen', marker='^', s=150, label='Long Entry', zorder=5)
    ax1.scatter(short_entries.index, short_entries['Close'], color='crimson', marker='v', s=150, label='Short Entry', zorder=5)
    
    ax1.set_title('Price + MAs + Trading Signals', fontsize=14, fontweight='bold')
    ax1.set_ylabel(f'Price ({PRICE_UNIT})', fontsize=11)
    ax1.legend(fontsize=9)
    ax1.grid(True, alpha=0.3)
    ax1.xaxis.set_major_locator(locator)
    ax1.xaxis.set_major_formatter(formatter)
    plt.setp(ax1.get_xticklabels(), rotation=45, ha='right')
    
    # Panel 2: MACD + BB Position
    ax2.plot(df.index, df['MACD'], label='MACD', color='blue', linewidth=1.5)
    ax2.plot(df.index, df['MACD_Signal'], label='Signal', color='orange', linewidth=1)
    ax2.fill_between(df.index, df['MACD'] - df['MACD_Signal'], 0, alpha=0.2, color=['green' if x > 0 else 'red' for x in (df['MACD'] - df['MACD_Signal'])])
    ax2.axhline(y=0, color='gray', linestyle='--', alpha=0.5)
    ax2.set_title('MACD + Bollinger Position', fontsize=14, fontweight='bold')
    ax2.set_ylabel('MACD Value', fontsize=11)
    ax2.legend(loc='upper left', fontsize=9)
    ax2.grid(True, alpha=0.3)
    ax2.xaxis.set_major_locator(locator)
    ax2.xaxis.set_major_formatter(formatter)
    plt.setp(ax2.get_xticklabels(), rotation=45, ha='right')

    # Panel 3: ML Prediction Probabilities
    ax3.plot(df.index, df['Prob_Long'], color='green', linewidth=2, label='Long Prob')
    ax3.plot(df.index, df['Prob_Short'], color='red', linewidth=2, label='Short Prob')
    ax3.plot(df.index, df['Prob_Neutral'], color='gray', linewidth=1, linestyle='--', label='Neutral Prob')
    ax3.set_title('ML Prediction Probabilities', fontsize=14, fontweight='bold')
    ax3.set_ylabel('Probability', fontsize=11)
    ax3.legend(fontsize=9)
    ax3.set_ylim(0, 1)
    ax3.grid(True, alpha=0.3)
    ax3.xaxis.set_major_locator(locator)
    ax3.xaxis.set_major_formatter(formatter)
    plt.setp(ax3.get_xticklabels(), rotation=45, ha='right')

    # Panel 4: Position Status
    ax4.plot(df.index, df['Position'], color='black', linewidth=2, label='Position Status')
    ax4.set_title('Position Status Changes', fontsize=14, fontweight='bold')
    ax4.set_ylabel('Position', fontsize=11)
    ax4.set_xlabel('Time', fontsize=11)
    ax4.set_ylim(-1.5, 1.5)
    ax4.grid(True, alpha=0.3)
    ax4.xaxis.set_major_locator(locator)
    ax4.xaxis.set_major_formatter(formatter)
    plt.setp(ax4.get_xticklabels(), rotation=45, ha='right')
    
    plt.tight_layout(rect=[0, 0, 1, 0.96])
    # plt.show() # 在非互動式環境中，此行會導致程式掛起
    
    # Performance Summary Printout
    report_lines = [
        "\n" + "="*50,
        "Bi-Directional Trading Performance Summary",
        "="*50
    ]
    for key, value in performance.items():
        if isinstance(value, float):
            report_lines.append(f"{key:<25}: {value:.2f}")
        else:
            report_lines.append(f"{key:<25}: {value}")
    report_lines.append("="*50)
    logging.info("\n".join(report_lines))
    
    return True
